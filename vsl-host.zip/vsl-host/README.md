# VSL Host — tu propio Vidalytics

Alojamiento de VSLs con player optimizado para conversión, analíticas de retención y ventas, CTA temporizado, formularios y preguntas dentro del vídeo, webinars evergreen, protección contra descargas, eventos a Meta y tests A/B.

> **¿Ya tenías la v1 instalada?** Vuelve a ejecutar `supabase/schema.sql` entero en el SQL Editor (no borra nada, solo añade lo nuevo) y vuelve a desplegar.

**Piezas:**
- **Cloudflare Stream**: guarda, codifica y sirve los vídeos (HLS adaptativo, rápido en móvil).
- **Supabase**: login y base de datos (vídeos, vistas, tests).
- **Vercel**: el panel + el script `embed.js` que pegas en tus landings.

---

## 1. Supabase (proyecto nuevo)

1. Crea un proyecto nuevo en supabase.com.
2. Ve a **SQL Editor**, pega todo el contenido de `supabase/schema.sql` y pulsa **Run**.
3. Ve a **Authentication → Sign In / Providers** y desactiva el registro de usuarios nuevos (solo entrarán los que tú crees).
4. Ve a **Authentication → Users → Add user** y crea tu usuario (y uno por cada cliente). Cada usuario solo ve sus propios vídeos.
5. En **Project Settings → API** copia: Project URL, `anon` key y `service_role` key.

## 2. Cloudflare Stream

1. En el panel de Cloudflare, copia tu **Account ID** (columna derecha de la portada de la cuenta).
2. Crea un token en **My Profile → API Tokens → Create Token → Custom token** con el permiso **Account · Stream · Edit**. Cópialo.
3. Sube cualquier vídeo de prueba en **Stream**, ábrelo y mira la URL HLS: tiene la forma `https://customer-XXXX.cloudflarestream.com/...`. Copia la parte `customer-XXXX`.

## 3. Vercel

1. Sube esta carpeta a un repositorio privado de GitHub e impórtalo en Vercel (Add New → Project).
2. En **Environment Variables** añade (ver `.env.example`):

| Variable | Valor |
|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | Project URL de Supabase |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | anon key |
| `SUPABASE_SERVICE_ROLE_KEY` | service_role key |
| `CLOUDFLARE_ACCOUNT_ID` | Account ID |
| `CLOUDFLARE_STREAM_TOKEN` | el token del paso 2 |
| `NEXT_PUBLIC_CF_STREAM_CUSTOMER` | `customer-XXXX` |
| `NEXT_PUBLIC_APP_URL` | la URL final, p. ej. `https://video.evolve.ad` (sin barra final) |
| `RESEND_API_KEY` | *(opcional)* para los avisos por email: crea una cuenta en resend.com y copia la API key |
| `NOTIFY_FROM` | *(opcional)* remitente de los avisos, p. ej. `VSL Host <avisos@tudominio.com>` (dominio verificado en Resend) |

3. Deploy. Luego en **Settings → Domains** añade tu subdominio (p. ej. `video.evolve.ad`) y crea en Namecheap el registro CNAME que Vercel te indique.
4. Si cambias `NEXT_PUBLIC_APP_URL` después, vuelve a desplegar.

> Cada visitante que ve el vídeo manda un latido cada 10 s de visionado. Con mucho tráfico eso son muchas llamadas a funciones de Vercel: vigila el uso y pasa a un plan de pago cuando escales (el plan Hobby además es para uso no comercial).

## 4. Uso

1. Entra en el panel → **+ Subir vídeo**. La subida va directa a Cloudflare (sin límite práctico de tamaño, reanudable si se corta).
2. Cuando aparezca como **Listo**, ajusta en la ficha del vídeo:
   - Autoplay silenciado + aviso "Tu vídeo ya ha comenzado / Haz clic para escuchar" (al pulsarlo empieza desde el segundo 0 con sonido).
   - Barra de progreso rápida, pausa, "continuar viendo" para quien vuelve.
   - **Pitch**: segundo en que aparecen las secciones ocultas de la landing y/o un botón bajo el vídeo. Acepta `750` o `12:30`.
3. Copia el código y pégalo en la landing (en Elementor, un widget HTML):

```html
<div data-vsl="ID"></div>
<script async src="https://video.evolve.ad/embed.js"></script>
```

### Secciones que aparecen en el pitch

Ponle a cualquier bloque de la landing la clase `vsl-reveal` (aparece en el segundo configurado en el panel) o el atributo `data-vsl-reveal="125"` (aparece en ese segundo). Quien ya llegó al pitch otra vez, las ve directamente al volver.

Para que no se vean ni un instante antes de que cargue el script, pega esto en el `<head>` de la landing:

```html
<style>.vsl-reveal:not(.vslh-on),[data-vsl-reveal]:not(.vslh-on){display:none!important}</style>
```

La página también recibe el evento `vsl:reveal` en `window` por si quieres disparar algo propio.

### Eventos a Meta

Si la landing tiene el Pixel instalado, el player envía por `fbq` los eventos personalizados **VSL_25, VSL_50, VSL_75, VSL_95** (porcentaje visto con sonido) y **VSL_Pitch**. Si además rellenas **Ajustes Meta** (ID del pixel + token de la API de Conversiones), se envían también desde el servidor con el mismo `event_id`, así Meta los deduplica.

### Tests A/B

En **Tests A/B** eliges dos vídeos y el % de tráfico. El test tiene su propio código de inserción (se usa igual que el de un vídeo). Cada visitante ve siempre la misma variante. El panel compara play rate, visionado medio y llegada al pitch, con un indicador de confianza estadística. Al marcar ganador, el mismo código pasa a mostrar solo la ganadora: no hay que tocar la landing.

### Analíticas

- **Cargas**: veces que se cargó el player.
- **Reproducciones**: personas que activaron el sonido / dieron a play.
- **Play rate**: reproducciones ÷ cargas.
- **Visionado medio** y **curva de retención**: hasta dónde llega la gente viendo con sonido.
- **Llegan al pitch**: % de reproducciones que alcanzan el segundo del pitch.
- Desglose por `utm_content` (anuncio), campaña, fuente y dispositivo. Las UTM se leen de la URL de la landing, así que usa en tus anuncios `utm_content={{ad.name}}` para ver la retención por anuncio.

### Conversiones (en qué momento del vídeo compran)

Pega en tu página de gracias (lo tienes listo para copiar en la ficha de cada vídeo):

```html
<script async src="https://video.evolve.ad/convert.js" data-value="97" data-funnel="Lanzamiento noviembre"></script>
```

La venta se atribuye a la sesión del vídeo de dos formas:
- El botón del player y los enlaces dentro de `vsl-reveal` (o con `data-vsl-link`) añaden `?vsl_sid=…` a la URL. Si tu checkout conserva parámetros hasta la página de gracias, funciona entre dominios.
- Si no, se usa la última sesión vista en ese navegador, **siempre que la página de gracias esté en el mismo dominio que la landing** (configura en tu plataforma de pago que la página de gracias redirija a una página tuya).

En las estadísticas verás conversiones, ingresos, ingresos por reproducción, barras verdes en la curva de retención (en qué segundo estaban cuando compraron) y el desglose por anuncio y por embudo.

### Formulario dentro del vídeo

Pide nombre, email, teléfono o campos personalizados antes de empezar o en un segundo concreto (puede ser opcional, con botón para saltar). Todos los textos se editan. Los leads aparecen en **Leads** (descargables en CSV), se pueden avisar por email/webhook y se añaden a GetResponse si lo configuras.

### Preguntas interactivas

El vídeo se para y muestra una pregunta. Según la respuesta: sigue, salta a un segundo, cambia a otro vídeo o va a una página. Las respuestas salen en las estadísticas del vídeo.

### Webinar evergreen

Modo que simula un directo: sesiones a horas fijas (por ejemplo, 19:00 y 21:30, días a elegir) o cada X minutos. Antes de la hora se ve una cuenta atrás; durante la sesión, quien entra se une al punto en que va, con la etiqueta "EN DIRECTO", sin pausar ni retroceder; al acabar muestra la cuenta atrás a la siguiente.

### Protección

Con "Proteger contra descargas", el vídeo solo se sirve con enlaces firmados que caducan (no se puede descargar ni copiar el enlace a otra web). Con "Solo en estos dominios" no se reproduce fuera de tus webs. La primera vez que lo activas se crea sola la clave de firma en Cloudflare. Ojo: nadie puede impedir al 100% que alguien grabe su pantalla.

### GIF para emails

En la ficha del vídeo eliges el segundo y la duración y te da el código HTML del GIF enlazado a tu landing.

### Avisos

En Ajustes pones tu email y/o un webhook (Make, Zapier, n8n, Slack…). En cada vídeo eliges qué avisar: alguien empieza a verlo, llega al pitch, deja sus datos o compra.

### Looker Studio / Google Sheets

En Ajustes tienes una fórmula `=IMPORTDATA(...)` para Google Sheets con los datos diarios de cada vídeo. Conecta esa hoja a Looker Studio.

### Otros ajustes del player

Autoplay solo en móvil / solo en ordenador / siempre / nunca · grosor de la barra · botón de pantalla completa (sale solo cuando aparece el botón de compra) · estilo del botón (colores, tamaño, forma, animación, ancho completo) · "continuar viendo" con caducidad en días · porcentaje de carga mientras carga · copiar ajustes de otro vídeo · modo oscuro del panel · zona horaria de las estadísticas.

## Desarrollo local

```bash
cp .env.example .env.local   # y rellena
npm install
npm run dev
```
