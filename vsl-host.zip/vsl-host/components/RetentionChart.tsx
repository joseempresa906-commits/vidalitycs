'use client';

import { useState } from 'react';

type Pt = { s: number; pct: number };
type Series = { name: string; color: string; data: Pt[] };

function fmt(s: number) {
  s = Math.round(s);
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
}

export default function RetentionChart({
  series,
  duration,
  markers = [],
  bars = [],
}: {
  series: Series[];
  duration: number;
  markers?: { s: number; label: string }[];
  bars?: number[];
}) {
  const [hover, setHover] = useState<number | null>(null);
  const W = 900, H = 280, L = 40, R = 12, T = 12, B = 28;
  const iw = W - L - R, ih = H - T - B;
  const x = (s: number) => L + (duration ? (s / duration) * iw : 0);
  const y = (p: number) => T + ih - (p / 100) * ih;

  if (!duration || series.every((s) => !s.data.length)) {
    return <p className="hint">Aún no hay reproducciones en este periodo.</p>;
  }

  const ticks = 6;
  const hs = hover != null ? (hover / 100) * duration : null;
  const at = (d: Pt[], s: number) => {
    if (!d.length) return null;
    const i = Math.round((s / duration) * (d.length - 1));
    return d[Math.max(0, Math.min(d.length - 1, i))];
  };

  return (
    <div style={{ position: 'relative' }}>
      <svg
        viewBox={`0 0 ${W} ${H}`}
        style={{ width: '100%', height: 'auto', display: 'block' }}
        onMouseMove={(e) => {
          const r = (e.currentTarget as SVGSVGElement).getBoundingClientRect();
          const px = ((e.clientX - r.left) / r.width) * W;
          setHover(Math.max(0, Math.min(100, ((px - L) / iw) * 100)));
        }}
        onMouseLeave={() => setHover(null)}
      >
        {[0, 25, 50, 75, 100].map((p) => (
          <g key={p}>
            <line x1={L} x2={W - R} y1={y(p)} y2={y(p)} stroke="var(--line)" />
            <text x={L - 6} y={y(p) + 4} fontSize="11" textAnchor="end" fill="var(--mute)">{p}%</text>
          </g>
        ))}
        {Array.from({ length: ticks + 1 }, (_, i) => (duration * i) / ticks).map((s, i) => (
          <text key={i} x={x(s)} y={H - 8} fontSize="11" textAnchor="middle" fill="var(--mute)">{fmt(s)}</text>
        ))}
        {markers.map((m) => (
          <g key={m.label}>
            <line x1={x(m.s)} x2={x(m.s)} y1={T} y2={T + ih} stroke="#b45309" strokeDasharray="4 4" />
            <text x={x(m.s) + 4} y={T + 12} fontSize="11" fill="#b45309">{m.label}</text>
          </g>
        ))}
        {series.map((sr) =>
          sr.data.length ? (
            <g key={sr.name}>
              <path
                d={`M${x(0)},${y(0)} ` + sr.data.map((p) => `L${x(p.s)},${y(p.pct)}`).join(' ') + ` L${x(duration)},${y(0)} Z`}
                fill={sr.color}
                opacity={series.length > 1 ? 0.06 : 0.12}
              />
              <path d={sr.data.map((p, i) => `${i ? 'L' : 'M'}${x(p.s)},${y(p.pct)}`).join(' ')} fill="none" stroke={sr.color} strokeWidth="2" />
            </g>
          ) : null
        )}
        {bars.some((b) => b > 0) &&
          bars.map((b, i) => {
            if (!b) return null;
            const maxB = Math.max(...bars);
            const h = (b / maxB) * ih * 0.35;
            const s = (duration * i) / (bars.length - 1);
            return <rect key={i} x={x(s) - 3} y={T + ih - h} width={6} height={h} fill="#15803d" opacity={0.85} rx={1} />;
          })}
        {hs != null && <line x1={x(hs)} x2={x(hs)} y1={T} y2={T + ih} stroke="#333" strokeWidth="1" />}
      </svg>
      {hs != null && (
        <div
          style={{
            position: 'absolute', top: 8, left: `${Math.min(80, Math.max(5, hover!))}%`,
            background: '#141412', color: '#fff', padding: '6px 10px', borderRadius: 6, fontSize: 12,
            pointerEvents: 'none', whiteSpace: 'nowrap',
          }}
        >
          <b>{fmt(hs)}</b>
          {series.map((sr) => {
            const p = at(sr.data, hs);
            return p ? <div key={sr.name}><span style={{ color: sr.color }}>●</span> {sr.name}: {p.pct.toFixed(1)}%</div> : null;
          })}
          {bars.length > 1 && (() => {
            const i = Math.round((hs / duration) * (bars.length - 1));
            const n = (bars[i - 1] || 0) + (bars[i] || 0) + (bars[i + 1] || 0);
            return n ? <div><span style={{ color: '#15803d' }}>■</span> Ventas aquí: {n}</div> : null;
          })()}
        </div>
      )}
    </div>
  );
}
