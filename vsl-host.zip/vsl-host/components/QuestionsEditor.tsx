'use client';

import { useState } from 'react';

type Opt = { label: string; action: string; seconds?: string; video?: string; url?: string };
type Q = { at: string; text: string; options: Opt[] };

function toMMSS(s: any) {
  const n = Number(s);
  if (s === null || s === undefined || s === '' || isNaN(n)) return '';
  return `${Math.floor(n / 60)}:${String(Math.round(n % 60)).padStart(2, '0')}`;
}

export default function QuestionsEditor({
  initial,
  videos,
}: {
  initial: any[];
  videos: { id: string; name: string }[];
}) {
  const [qs, setQs] = useState<Q[]>(
    (initial || []).map((q) => ({
      at: toMMSS(q.at),
      text: q.text,
      options: (q.options || []).map((o: any) => ({ ...o, seconds: toMMSS(o.seconds) })),
    }))
  );
  const upd = (i: number, p: Partial<Q>) => setQs(qs.map((q, j) => (j === i ? { ...q, ...p } : q)));
  const updOpt = (i: number, k: number, p: Partial<Opt>) =>
    upd(i, { options: qs[i].options.map((o, j) => (j === k ? { ...o, ...p } : o)) });

  return (
    <div>
      <input type="hidden" name="questions" value={JSON.stringify(qs)} />
      {qs.map((q, i) => (
        <div key={i} className="subcard">
          <div className="grid" style={{ gridTemplateColumns: '110px 1fr auto', gap: 8 }}>
            <input type="text" placeholder="1:30" value={q.at} onChange={(e) => upd(i, { at: e.target.value })} />
            <input type="text" placeholder="Pregunta" value={q.text} onChange={(e) => upd(i, { text: e.target.value })} />
            <button type="button" className="btn ghost" onClick={() => setQs(qs.filter((_, j) => j !== i))}>✕</button>
          </div>
          {q.options.map((o, k) => (
            <div key={k} className="grid" style={{ gridTemplateColumns: '1fr 150px 1fr auto', gap: 8, marginTop: 8 }}>
              <input type="text" placeholder="Respuesta" value={o.label} onChange={(e) => updOpt(i, k, { label: e.target.value })} />
              <select value={o.action} onChange={(e) => updOpt(i, k, { action: e.target.value })}>
                <option value="continue">Seguir el vídeo</option>
                <option value="seek">Saltar a un segundo</option>
                <option value="video">Cambiar a otro vídeo</option>
                <option value="url">Ir a una página</option>
              </select>
              {o.action === 'seek' ? (
                <input type="text" placeholder="mm:ss" value={o.seconds || ''} onChange={(e) => updOpt(i, k, { seconds: e.target.value })} />
              ) : o.action === 'video' ? (
                <select value={o.video || ''} onChange={(e) => updOpt(i, k, { video: e.target.value })}>
                  <option value="">Elige vídeo…</option>
                  {videos.map((v) => <option key={v.id} value={v.id}>{v.name}</option>)}
                </select>
              ) : o.action === 'url' ? (
                <input type="text" placeholder="https://…" value={o.url || ''} onChange={(e) => updOpt(i, k, { url: e.target.value })} />
              ) : (
                <span />
              )}
              <button type="button" className="btn ghost" onClick={() => upd(i, { options: q.options.filter((_, j) => j !== k) })}>✕</button>
            </div>
          ))}
          <button type="button" className="btn ghost" style={{ marginTop: 8 }} onClick={() => upd(i, { options: [...q.options, { label: '', action: 'continue' }] })}>
            + Respuesta
          </button>
        </div>
      ))}
      <button
        type="button"
        className="btn ghost"
        onClick={() => setQs([...qs, { at: '', text: '', options: [{ label: 'Sí', action: 'continue' }, { label: 'No', action: 'continue' }] }])}
      >
        + Añadir pregunta
      </button>
    </div>
  );
}
