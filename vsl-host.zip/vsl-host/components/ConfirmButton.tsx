'use client';

export default function ConfirmButton({
  action,
  label,
  question,
}: {
  action: () => Promise<void>;
  label: string;
  question: string;
}) {
  return (
    <button
      className="btn danger"
      formAction={action}
      onClick={(e) => {
        if (!confirm(question)) e.preventDefault();
      }}
    >
      {label}
    </button>
  );
}
