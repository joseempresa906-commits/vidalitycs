/** Barras diarias de reproducciones (y conversiones encima). */
export default function DailyChart({ data }: { data: { day: string; plays: number; conv: number }[] }) {
  if (data.length < 2) return <p className="hint">Necesitas al menos dos días de datos.</p>;
  const W = 900, H = 180, L = 34, B = 24, T = 10;
  const max = Math.max(...data.map((d) => d.plays), 1);
  const bw = (W - L) / data.length;
  const y = (v: number) => T + (H - T - B) * (1 - v / max);
  const every = Math.ceil(data.length / 10);
  return (
    <svg viewBox={`0 0 ${W} ${H}`} style={{ width: '100%', height: 'auto', display: 'block' }}>
      {[0, 0.5, 1].map((p) => (
        <g key={p}>
          <line x1={L} x2={W} y1={y(max * p)} y2={y(max * p)} stroke="var(--line)" />
          <text x={L - 6} y={y(max * p) + 4} fontSize="11" textAnchor="end" fill="var(--mute)">{Math.round(max * p)}</text>
        </g>
      ))}
      {data.map((d, i) => (
        <g key={d.day}>
          <rect x={L + i * bw + bw * 0.15} y={y(d.plays)} width={bw * 0.7} height={H - B - y(d.plays)} fill="var(--accent)" opacity="0.75" rx="2">
            <title>{`${d.day}: ${d.plays} reproducciones, ${d.conv} conversiones`}</title>
          </rect>
          {d.conv > 0 && (
            <rect x={L + i * bw + bw * 0.15} y={y(d.conv)} width={bw * 0.7} height={H - B - y(d.conv)} fill="var(--ok)" rx="2" />
          )}
          {i % every === 0 && (
            <text x={L + i * bw + bw / 2} y={H - 6} fontSize="10.5" textAnchor="middle" fill="var(--mute)">{d.day.slice(5)}</text>
          )}
        </g>
      ))}
    </svg>
  );
}
