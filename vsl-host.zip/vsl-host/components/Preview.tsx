'use client';

import { useEffect, useRef } from 'react';

/** Vista previa del player real (sin tracking). */
export default function Preview({ id, version }: { id: string; version: string }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!ref.current) return;
    ref.current.innerHTML = `<div data-vsl="${id}" data-preview="1"></div>`;
    const w = window as any;
    if (w.__vslh) w.__vslh.scan();
    else {
      const s = document.createElement('script');
      s.src = '/embed.js';
      s.async = true;
      document.body.appendChild(s);
    }
  }, [id, version]);
  return <div ref={ref} />;
}
