'use client';

import { useRef, useState } from 'react';
import * as tus from 'tus-js-client';

export default function Uploader() {
  const input = useRef<HTMLInputElement>(null);
  const [pct, setPct] = useState<number | null>(null);
  const [err, setErr] = useState('');

  function pick(file: File) {
    setErr('');
    setPct(0);
    let videoId = '';
    const up = new tus.Upload(file, {
      endpoint: '/api/upload',
      chunkSize: 50 * 1024 * 1024, // 50 MB (Cloudflare pide múltiplos de 256 KiB)
      retryDelays: [0, 2000, 5000, 10000],
      metadata: { name: file.name, filetype: file.type },
      onAfterResponse(_req, res) {
        const id = res.getHeader('X-Video-Id');
        if (id) videoId = id;
      },
      onProgress(sent, total) {
        setPct(Math.round((sent / total) * 100));
      },
      onError(e) {
        setErr('Error al subir: ' + e.message);
        setPct(null);
      },
      onSuccess() {
        window.location.href = videoId ? `/videos/${videoId}` : '/';
      },
    });
    up.start();
  }

  return (
    <div>
      <input
        ref={input}
        type="file"
        accept="video/*"
        hidden
        onChange={(e) => e.target.files?.[0] && pick(e.target.files[0])}
      />
      {pct === null ? (
        <button className="btn accent" onClick={() => input.current?.click()}>
          + Subir vídeo
        </button>
      ) : (
        <div style={{ minWidth: 240 }}>
          <div className="row between" style={{ marginBottom: 6 }}>
            <span>Subiendo…</span>
            <b>{pct}%</b>
          </div>
          <div className="progress"><i style={{ width: `${pct}%` }} /></div>
        </div>
      )}
      {err && <p className="err">{err}</p>}
    </div>
  );
}
