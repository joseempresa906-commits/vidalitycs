'use client';

import { useState } from 'react';

type F = { key: string; label: string; type: string; required: boolean };

const DEFAULT: F[] = [
  { key: 'name', label: 'Tu nombre', type: 'text', required: true },
  { key: 'email', label: 'Tu email', type: 'email', required: true },
];

/** Campos del formulario. Las claves name, email y phone se guardan en columnas propias; el resto, como campos personalizados. */
export default function GateFieldsEditor({ initial }: { initial: F[] }) {
  const [fs, setFs] = useState<F[]>(initial?.length ? initial : DEFAULT);
  const upd = (i: number, p: Partial<F>) => setFs(fs.map((f, j) => (j === i ? { ...f, ...p } : f)));
  return (
    <div>
      <input type="hidden" name="gate_fields" value={JSON.stringify(fs)} />
      {fs.map((f, i) => (
        <div key={i} className="grid" style={{ gridTemplateColumns: '1fr 1fr 120px auto auto', gap: 8, marginBottom: 8, alignItems: 'center' }}>
          <input type="text" placeholder="Texto del campo" value={f.label} onChange={(e) => upd(i, { label: e.target.value })} />
          <select
            value={['name', 'email', 'phone'].includes(f.key) ? f.key : 'custom'}
            onChange={(e) =>
              upd(i, e.target.value === 'custom'
                ? { key: `campo_${i + 1}`, type: 'text' }
                : { key: e.target.value, type: e.target.value === 'email' ? 'email' : e.target.value === 'phone' ? 'tel' : 'text' })
            }
          >
            <option value="name">Nombre</option>
            <option value="email">Email</option>
            <option value="phone">Teléfono</option>
            <option value="custom">Personalizado</option>
          </select>
          {['name', 'email', 'phone'].includes(f.key) ? (
            <span className="hint">{f.type}</span>
          ) : (
            <input type="text" title="Nombre interno" value={f.key} onChange={(e) => upd(i, { key: e.target.value.replace(/\W+/g, '_').toLowerCase() })} />
          )}
          <label className="check" style={{ margin: 0 }}>
            <input type="checkbox" checked={f.required} onChange={(e) => upd(i, { required: e.target.checked })} /> Oblig.
          </label>
          <button type="button" className="btn ghost" onClick={() => setFs(fs.filter((_, j) => j !== i))}>✕</button>
        </div>
      ))}
      <button type="button" className="btn ghost" onClick={() => setFs([...fs, { key: `campo_${fs.length + 1}`, label: '', type: 'text', required: false }])}>
        + Campo
      </button>
    </div>
  );
}
