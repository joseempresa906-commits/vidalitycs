'use client';

import { useState } from 'react';

export default function CopyBox({ text }: { text: string }) {
  const [ok, setOk] = useState(false);
  return (
    <div>
      <pre className="code">{text}</pre>
      <button
        className="btn ghost"
        type="button"
        onClick={() => {
          navigator.clipboard.writeText(text);
          setOk(true);
          setTimeout(() => setOk(false), 1500);
        }}
      >
        {ok ? '¡Copiado!' : 'Copiar'}
      </button>
    </div>
  );
}
