'use client';

import { useState } from 'react';
import CopyBox from './CopyBox';

/** GIF animado del vídeo para poner en emails, enlazado a tu landing. */
export default function GifBuilder({ id, app }: { id: string; app: string }) {
  const [s, setS] = useState('5');
  const [d, setD] = useState('4');
  const [link, setLink] = useState('https://');
  const [shown, setShown] = useState('');
  const secs = (v: string) => (v.includes(':') ? v.split(':').reduce((a, p) => a * 60 + Number(p || 0), 0) : Number(v) || 0);
  const url = `${app}/api/gif/${id}?s=${secs(s)}&d=${Math.min(15, secs(d) || 4)}&h=360`;
  const html = `<a href="${link}" target="_blank"><img src="${url}" width="480" style="max-width:100%;border-radius:8px" alt="Ver vídeo"></a>`;

  return (
    <div>
      <div className="grid g3" style={{ gap: 10 }}>
        <div className="field"><label>Empieza en</label><input type="text" value={s} onChange={(e) => setS(e.target.value)} placeholder="0:05" /></div>
        <div className="field"><label>Duración (seg., máx. 15)</label><input type="text" value={d} onChange={(e) => setD(e.target.value)} /></div>
        <div className="field"><label>Enlace al pulsar</label><input type="text" value={link} onChange={(e) => setLink(e.target.value)} /></div>
      </div>
      <button type="button" className="btn ghost" onClick={() => setShown(url + '&r=' + Date.now())} style={{ marginBottom: 12 }}>
        Ver GIF
      </button>
      {shown && (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={shown} alt="" style={{ display: 'block', maxWidth: '100%', borderRadius: 8, marginBottom: 12 }} />
      )}
      <label>Código para el email</label>
      <CopyBox text={html} />
    </div>
  );
}
