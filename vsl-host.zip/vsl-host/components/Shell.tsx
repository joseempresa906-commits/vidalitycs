import Link from 'next/link';
import type { ReactNode } from 'react';
import { signOut } from '@/app/actions';
import ThemeToggle from './ThemeToggle';

export default function Shell({ children }: { children: ReactNode }) {
  return (
    <div className="shell">
      <nav className="side">
        <div className="logo">VSL<i>●</i>Host</div>
        <Link href="/">Vídeos</Link>
        <Link href="/tests">Tests A/B</Link>
        <Link href="/leads">Leads</Link>
        <Link href="/settings">Ajustes</Link>
        <div style={{ marginTop: 'auto', display: 'flex', flexDirection: 'column' }}>
          <ThemeToggle />
          <form action={signOut}>
            <button type="submit">Cerrar sesión</button>
          </form>
        </div>
      </nav>
      <main>{children}</main>
    </div>
  );
}
