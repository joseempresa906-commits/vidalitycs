'use client';

import { useEffect, useState } from 'react';

export default function ThemeToggle() {
  const [dark, setDark] = useState(false);
  useEffect(() => setDark(document.documentElement.dataset.theme === 'dark'), []);
  return (
    <button
      type="button"
      className="sidebtn"
      onClick={() => {
        const next = !dark;
        setDark(next);
        document.documentElement.dataset.theme = next ? 'dark' : 'light';
        try { localStorage.setItem('vslh_theme', next ? 'dark' : 'light'); } catch {}
      }}
    >
      {dark ? '☀︎ Modo claro' : '☾ Modo oscuro'}
    </button>
  );
}
