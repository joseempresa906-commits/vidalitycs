import './globals.css';
import type { ReactNode } from 'react';

export const metadata = { title: 'VSL Host', robots: { index: false } };

// Aplica el modo oscuro antes de pintar para evitar el parpadeo
const themeScript = `try{var t=localStorage.getItem('vslh_theme');if(t)document.documentElement.dataset.theme=t}catch(e){}`;

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="es" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeScript }} />
      </head>
      <body>{children}</body>
    </html>
  );
}
