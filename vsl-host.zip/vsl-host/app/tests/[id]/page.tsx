import Link from 'next/link';
import { notFound, redirect } from 'next/navigation';
import Shell from '@/components/Shell';
import RetentionChart from '@/components/RetentionChart';
import CopyBox from '@/components/CopyBox';
import ConfirmButton from '@/components/ConfirmButton';
import { requireUser } from '@/lib/supabase';
import { summarize, retention, confidence, fetchAll, pct, mmss, money, VIEW_COLS, type ViewRow } from '@/lib/stats';
import { setTestWinner, deleteTest } from '@/app/actions';

export const dynamic = 'force-dynamic';

export default async function TestPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const { sb, user } = await requireUser();
  if (!user) redirect('/login');

  const { data: t } = await sb.from('ab_tests').select('*').eq('id', id).maybeSingle();
  if (!t) notFound();
  const [{ data: vids }, rows] = await Promise.all([
    sb.from('videos').select('id,name,duration').in('id', [t.video_a, t.video_b]),
    fetchAll<ViewRow>((a, b) => sb.from('views').select(VIEW_COLS).eq('test_id', id).range(a, b)),
  ]);
  const va = vids?.find((v) => v.id === t.video_a);
  const vb = vids?.find((v) => v.id === t.video_b);
  const all = rows;
  const A = all.filter((r) => r.variant === 'A');
  const B = all.filter((r) => r.variant === 'B');
  const sa = summarize(A, Number(va?.duration || 0));
  const sb2 = summarize(B, Number(vb?.duration || 0));
  const dur = Math.max(Number(va?.duration || 0), Number(vb?.duration || 0));

  const confPlay = confidence(sa.plays, sa.loads, sb2.plays, sb2.loads);
  const confPitch = confidence(sa.pitch, sa.plays, sb2.pitch, sb2.plays);
  const confConv = confidence(sa.conv, sa.plays, sb2.conv, sb2.plays);
  const lead = (a: number, b: number) => (a === b ? '' : a > b ? 'A' : 'B');

  const app = process.env.NEXT_PUBLIC_APP_URL || '';
  const embed = `<div data-vsl="${t.id}"></div>\n<script async src="${app}/embed.js"></script>`;

  const row = (label: string, a: string, b: string, win?: string) => (
    <tr>
      <td>{label}</td>
      <td className={win === 'A' ? 'win' : ''}>{a}</td>
      <td className={win === 'B' ? 'win' : ''}>{b}</td>
    </tr>
  );
  const confLabel = (c: number) =>
    c >= 0.95 ? <span className="pill ok">{pct(c)} — resultado fiable</span> : <span className="pill warn">{pct(c)} — faltan datos</span>;

  return (
    <Shell>
      <p className="hint"><Link href="/tests">← Tests</Link></p>
      <h1>{t.name}</h1>
      <p className="sub">
        {t.active ? `En curso · ${Math.round(Number(t.split) * 100)}% A / ${Math.round((1 - Number(t.split)) * 100)}% B` : `Cerrado · todo el tráfico va a la variante ${t.winner}`}
      </p>

      <div className="card">
        <table>
          <thead><tr><th></th><th>A · {va?.name}</th><th>B · {vb?.name}</th></tr></thead>
          <tbody>
            {row('Cargas', String(sa.loads), String(sb2.loads))}
            {row('Reproducciones', String(sa.plays), String(sb2.plays))}
            {row('Play rate', pct(sa.playRate), pct(sb2.playRate), lead(sa.playRate, sb2.playRate))}
            {row('Visionado medio', `${pct(sa.avgPct)} (${mmss(sa.avgSec)})`, `${pct(sb2.avgPct)} (${mmss(sb2.avgSec)})`, lead(sa.avgSec, sb2.avgSec))}
            {row('Llegan al pitch', pct(sa.pitchRate), pct(sb2.pitchRate), lead(sa.pitchRate, sb2.pitchRate))}
            {row('Conversiones', `${sa.conv} (${pct(sa.convRate)})`, `${sb2.conv} (${pct(sb2.convRate)})`, lead(sa.convRate, sb2.convRate))}
            {row('Ingresos por reproducción', money(sa.plays ? sa.revenue / sa.plays : 0), money(sb2.plays ? sb2.revenue / sb2.plays : 0), lead(sa.plays ? sa.revenue / sa.plays : 0, sb2.plays ? sb2.revenue / sb2.plays : 0))}
          </tbody>
        </table>
        <div className="row" style={{ marginTop: 14 }}>
          <span>Confianza en play rate: {confLabel(confPlay)}</span>
          <span>Confianza en llegada al pitch: {confLabel(confPitch)}</span>
          {(sa.conv + sb2.conv) > 0 && <span>Confianza en conversión: {confLabel(confConv)}</span>}
        </div>
      </div>

      <div className="card">
        <h2>Retención comparada</h2>
        <RetentionChart
          duration={dur}
          series={[
            { name: 'A', color: '#E11D48', data: retention(A, Number(va?.duration || 0)) },
            { name: 'B', color: '#2563EB', data: retention(B, Number(vb?.duration || 0)) },
          ]}
        />
      </div>

      <div className="grid g2">
        <div className="card">
          <h2>Código para tu landing</h2>
          <CopyBox text={embed} />
          <p className="hint" style={{ marginTop: 10 }}>Cada visitante ve siempre la misma variante.</p>
        </div>
        <form className="card">
          <h2>Cerrar test</h2>
          <p className="hint">Al elegir ganador, el mismo código pasa a mostrar solo esa variante.</p>
          <div className="row">
            <button className="btn" formAction={setTestWinner.bind(null, t.id, 'A')}>Gana A</button>
            <button className="btn" formAction={setTestWinner.bind(null, t.id, 'B')}>Gana B</button>
            {!t.active && <button className="btn ghost" formAction={setTestWinner.bind(null, t.id, null)}>Reabrir</button>}
            <ConfirmButton action={deleteTest.bind(null, t.id)} label="Eliminar" question="¿Eliminar este test?" />
          </div>
        </form>
      </div>
    </Shell>
  );
}
