import Link from 'next/link';
import { redirect } from 'next/navigation';
import Shell from '@/components/Shell';
import { requireUser } from '@/lib/supabase';
import { createTest } from '@/app/actions';

export const dynamic = 'force-dynamic';

export default async function Tests() {
  const { sb, user } = await requireUser();
  if (!user) redirect('/login');
  const [{ data: tests }, { data: videos }] = await Promise.all([
    sb.from('ab_tests').select('*').order('created_at', { ascending: false }),
    sb.from('videos').select('id,name').eq('status', 'ready').order('created_at', { ascending: false }),
  ]);
  const name = (id: string) => videos?.find((v) => v.id === id)?.name || '—';

  return (
    <Shell>
      <h1>Tests A/B</h1>
      <p className="sub">Reparte el tráfico de una misma landing entre dos vídeos (otro hook, otra miniatura, otra versión) y compara.</p>

      <div className="grid g2">
        <div className="card">
          <h2>Tests</h2>
          <table>
            <thead><tr><th>Nombre</th><th>A</th><th>B</th><th>Estado</th></tr></thead>
            <tbody>
              {tests?.map((t) => (
                <tr key={t.id}>
                  <td><Link href={`/tests/${t.id}`}><b>{t.name}</b></Link></td>
                  <td>{name(t.video_a)}</td>
                  <td>{name(t.video_b)}</td>
                  <td>{t.active ? <span className="pill warn">En curso</span> : <span className="pill ok">Ganador {t.winner}</span>}</td>
                </tr>
              ))}
              {!tests?.length && <tr><td colSpan={4} className="hint">Aún no hay tests.</td></tr>}
            </tbody>
          </table>
        </div>

        <form className="card" action={createTest}>
          <h2>Nuevo test</h2>
          <div className="field"><label>Nombre</label><input type="text" name="name" placeholder="Hook nuevo vs. original" required /></div>
          <div className="field"><label>Variante A</label>
            <select name="video_a" required>{videos?.map((v) => <option key={v.id} value={v.id}>{v.name}</option>)}</select>
          </div>
          <div className="field"><label>Variante B</label>
            <select name="video_b" required>{videos?.map((v) => <option key={v.id} value={v.id}>{v.name}</option>)}</select>
          </div>
          <div className="field"><label>% de tráfico a A</label><input type="number" name="split" defaultValue={50} min={0} max={100} /></div>
          <button className="btn accent" disabled={(videos?.length || 0) < 2}>Crear test</button>
          {(videos?.length || 0) < 2 && <p className="hint">Necesitas al menos dos vídeos listos.</p>}
        </form>
      </div>
    </Shell>
  );
}
