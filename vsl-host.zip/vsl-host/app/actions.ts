'use server';

import { redirect } from 'next/navigation';
import { revalidatePath } from 'next/cache';
import { requireUser } from '@/lib/supabase';
import { deleteStreamVideo, getSigningKey, setStreamProtection } from '@/lib/cloudflare';
import { safeTz } from '@/lib/tz';

function num(v: FormDataEntryValue | null) {
  if (v === null || String(v).trim() === '') return null;
  const s = String(v).trim();
  if (s.includes(':')) return s.split(':').reduce((acc, p) => acc * 60 + Number(p || 0), 0); // "2:15"
  const n = Number(s.replace(',', '.'));
  return isNaN(n) ? null : n;
}
const str = (v: FormDataEntryValue | null) => (v === null ? null : String(v).trim() || null);
const bool = (v: FormDataEntryValue | null) => v === 'on';
function json<T>(v: FormDataEntryValue | null, fallback: T): T {
  try { return v ? JSON.parse(String(v)) : fallback; } catch { return fallback; }
}
function domainList(s: string | null) {
  return (s || '')
    .split(/[\s,]+/)
    .map((d) => d.trim().toLowerCase().replace(/^https?:\/\//, '').replace(/\/.*$/, ''))
    .filter(Boolean);
}

async function auth() {
  const { sb, user } = await requireUser();
  if (!user) redirect('/login');
  return { sb, user };
}

export async function signOut() {
  const { sb } = await requireUser();
  await sb.auth.signOut();
  redirect('/login');
}

export async function updateVideo(id: string, fd: FormData) {
  const { sb } = await auth();
  const { data: before } = await sb.from('videos').select('stream_uid, protected, allowed_domains').eq('id', id).single();
  if (!before) redirect('/');

  const days = [0, 1, 2, 3, 4, 5, 6].filter((d) => bool(fd.get(`ev_day_${d}`)));
  const questions = json<any[]>(fd.get('questions'), [])
    .filter((q) => q && q.text && q.at != null)
    .map((q) => ({
      at: num(String(q.at)) ?? 0,
      text: String(q.text),
      options: (q.options || []).filter((o: any) => o?.label).map((o: any) => ({
        label: String(o.label),
        action: ['continue', 'seek', 'video', 'url'].includes(o.action) ? o.action : 'continue',
        seconds: o.seconds !== '' && o.seconds != null ? num(String(o.seconds)) : null,
        video: o.video || null,
        url: o.url || null,
      })),
    }));

  const patch = {
    name: str(fd.get('name')) || 'Vídeo',
    aspect: str(fd.get('aspect')) || '16:9',
    color: str(fd.get('color')) || '#E11D48',
    autoplay_mode: str(fd.get('autoplay_mode')) || 'always',
    unmute_title: str(fd.get('unmute_title')) || 'Tu vídeo ya ha comenzado',
    unmute_subtitle: str(fd.get('unmute_subtitle')) || 'Haz clic para escuchar',
    fast_progress: bool(fd.get('fast_progress')),
    bar_height: Math.min(20, Math.max(2, num(fd.get('bar_height')) ?? 6)),
    allow_pause: bool(fd.get('allow_pause')),
    show_fullscreen: bool(fd.get('show_fullscreen')),
    resume_enabled: bool(fd.get('resume_enabled')),
    resume_days: Math.max(1, num(fd.get('resume_days')) ?? 30),
    thumbnail_time: num(fd.get('thumbnail_time')) ?? 1,
    reveal_at: num(fd.get('reveal_at')),
    cta_at: num(fd.get('cta_at')),
    cta_text: str(fd.get('cta_text')),
    cta_url: str(fd.get('cta_url')),
    cta_style: {
      bg: str(fd.get('cta_bg')),
      fg: str(fd.get('cta_fg')),
      size: str(fd.get('cta_size')) || 'm',
      shape: str(fd.get('cta_shape')) || 'rounded',
      anim: str(fd.get('cta_anim')) || 'none',
      full: bool(fd.get('cta_full')),
    },
    cta_exit_fullscreen: bool(fd.get('cta_exit_fullscreen')),
    meta_events: bool(fd.get('meta_events')),
    mode: str(fd.get('mode')) === 'evergreen' ? 'evergreen' : 'vsl',
    evergreen: {
      tz: safeTz(str(fd.get('ev_tz'))),
      times: (str(fd.get('ev_times')) || '').split(/[\s,;]+/).filter((t) => /^\d{1,2}:\d{2}$/.test(t)),
      days,
      every_minutes: num(fd.get('ev_every')) || null,
      labels: {
        countdown: str(fd.get('ev_label_countdown')),
        ended: str(fd.get('ev_label_ended')),
        live: str(fd.get('ev_label_live')),
      },
    },
    gate: {
      enabled: bool(fd.get('gate_enabled')),
      at: num(fd.get('gate_at')) ?? 0,
      title: str(fd.get('gate_title')),
      subtitle: str(fd.get('gate_subtitle')),
      button: str(fd.get('gate_button')),
      skippable: bool(fd.get('gate_skippable')),
      skipText: str(fd.get('gate_skip_text')),
      fields: json<any[]>(fd.get('gate_fields'), []).filter((f) => f?.key && f?.label),
    },
    questions,
    notify: {
      play: bool(fd.get('notify_play')),
      pitch: bool(fd.get('notify_pitch')),
      lead: bool(fd.get('notify_lead')),
      conversion: bool(fd.get('notify_conversion')),
    },
    webhook_url: str(fd.get('webhook_url')),
    protected: bool(fd.get('protected')),
    allowed_domains: domainList(str(fd.get('allowed_domains'))).join(', ') || null,
  };

  // Protección en Cloudflare (URLs firmadas + dominios)
  if (patch.protected !== before.protected || patch.allowed_domains !== before.allowed_domains) {
    try {
      if (patch.protected) await getSigningKey(true);
      const app = (process.env.NEXT_PUBLIC_APP_URL || '').replace(/^https?:\/\//, '');
      const domains = domainList(patch.allowed_domains);
      const origins = domains.length ? [...new Set([...domains, ...domains.map((d) => `*.${d}`), app].filter(Boolean))] : [];
      await setStreamProtection(before.stream_uid, patch.protected, origins);
    } catch (e: any) {
      redirect(`/videos/${id}?err=${encodeURIComponent('Cloudflare: ' + String(e?.message || e).slice(0, 200))}`);
    }
  }

  await sb.from('videos').update(patch).eq('id', id);
  revalidatePath(`/videos/${id}`);
  redirect(`/videos/${id}?ok=1`);
}

export async function deleteVideo(id: string) {
  const { sb } = await auth();
  const { data } = await sb.from('videos').select('stream_uid').eq('id', id).maybeSingle();
  if (data) {
    await deleteStreamVideo(data.stream_uid);
    await sb.from('videos').delete().eq('id', id);
  }
  redirect('/');
}

/** Copia los ajustes de otro vídeo (todo menos nombre, vídeo y formato). */
export async function copySettings(id: string, fd: FormData) {
  const { sb } = await auth();
  const from = str(fd.get('from'));
  if (!from) return;
  const { data: src } = await sb.from('videos').select('*').eq('id', from).single();
  if (!src) return;
  const { id: _i, owner_id: _o, name: _n, stream_uid: _s, status: _st, duration: _d, aspect: _a, created_at: _c, protected: _p, allowed_domains: _ad, ...rest } = src;
  await sb.from('videos').update(rest).eq('id', id);
  redirect(`/videos/${id}?ok=1`);
}

export async function createTest(fd: FormData) {
  const { sb, user } = await auth();
  const a = str(fd.get('video_a'));
  const b = str(fd.get('video_b'));
  if (!a || !b || a === b) return;
  const split = Math.min(100, Math.max(0, num(fd.get('split')) ?? 50)) / 100;
  const { data } = await sb
    .from('ab_tests')
    .insert({ owner_id: user.id, name: str(fd.get('name')) || 'Test A/B', video_a: a, video_b: b, split })
    .select('id')
    .single();
  if (data) redirect(`/tests/${data.id}`);
}

export async function setTestWinner(id: string, winner: 'A' | 'B' | null) {
  const { sb } = await auth();
  await sb.from('ab_tests').update({ winner, active: winner === null }).eq('id', id);
  revalidatePath(`/tests/${id}`);
}

export async function deleteTest(id: string) {
  const { sb } = await auth();
  await sb.from('ab_tests').delete().eq('id', id);
  redirect('/tests');
}

export async function saveSettings(fd: FormData) {
  const { sb, user } = await auth();
  await sb.from('settings').upsert({
    owner_id: user.id,
    meta_pixel_id: str(fd.get('meta_pixel_id')),
    meta_capi_token: str(fd.get('meta_capi_token')),
    meta_test_event_code: str(fd.get('meta_test_event_code')),
    timezone: safeTz(str(fd.get('timezone'))),
    notify_email: str(fd.get('notify_email')),
    webhook_url: str(fd.get('webhook_url')),
    getresponse_key: str(fd.get('getresponse_key')),
    getresponse_campaign: str(fd.get('getresponse_campaign')),
    updated_at: new Date().toISOString(),
  });
  revalidatePath('/settings');
  redirect('/settings?ok=1');
}

export async function regenerateExportToken() {
  const { sb, user } = await auth();
  await sb.from('settings').upsert({ owner_id: user.id, export_token: crypto.randomUUID() });
  redirect('/settings?ok=1');
}
