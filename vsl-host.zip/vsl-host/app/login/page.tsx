'use client';

import { useState } from 'react';
import { createBrowserClient } from '@supabase/ssr';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError('');
    const sb = createBrowserClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!);
    const { error } = await sb.auth.signInWithPassword({ email, password });
    if (error) {
      setError('Email o contraseña incorrectos');
      setBusy(false);
    } else window.location.href = '/';
  }

  return (
    <form className="login" onSubmit={submit}>
      <h1>VSL Host</h1>
      <p className="sub">Entra con tu cuenta</p>
      <div className="field">
        <label>Email</label>
        <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
      </div>
      <div className="field">
        <label>Contraseña</label>
        <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
      </div>
      <button className="btn accent" disabled={busy} style={{ width: '100%', justifyContent: 'center' }}>
        {busy ? 'Entrando…' : 'Entrar'}
      </button>
      {error && <p className="err">{error}</p>}
    </form>
  );
}
