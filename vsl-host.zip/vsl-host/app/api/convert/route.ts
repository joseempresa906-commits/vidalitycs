import { NextResponse } from 'next/server';
import { supabaseAdmin } from '@/lib/supabase';
import { notify } from '@/lib/notify';

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type',
};

export async function OPTIONS() {
  return new NextResponse(null, { status: 204, headers: CORS });
}

/** Lo llama convert.js desde la página de gracias. Atribuye la venta a la sesión del vídeo. */
export async function POST(req: Request) {
  let b: any;
  try { b = JSON.parse(await req.text()); } catch { return new NextResponse(null, { status: 400, headers: CORS }); }
  const sid = String(b.sid || '').slice(0, 64);
  if (!sid) return new NextResponse(null, { status: 400, headers: CORS });

  const sb = supabaseAdmin();
  const { data: row } = await sb.from('views').select('*').eq('session_id', sid).maybeSingle();
  if (!row) return new NextResponse(null, { status: 404, headers: CORS });
  if (row.converted) return new NextResponse(null, { status: 204, headers: CORS }); // solo una vez por sesión

  const value = Number(String(b.value ?? '').replace(',', '.'));
  const second = row.click_second ?? row.max_second;
  await sb
    .from('views')
    .update({
      converted: true,
      converted_at: new Date().toISOString(),
      conversion_value: isNaN(value) ? null : value,
      conversion_second: second,
      conversion_page: String(b.page || '').slice(0, 500) || null,
      funnel: String(b.funnel || '').slice(0, 120) || null,
    })
    .eq('id', row.id);

  const { data: video } = await sb.from('videos').select('id, owner_id, name, notify, webhook_url').eq('id', row.video_id).maybeSingle();
  if (video) {
    const { data: s } = await sb.from('settings').select('*').eq('owner_id', video.owner_id).maybeSingle();
    await notify('conversion', video, s, {
      valor: isNaN(value) ? null : value,
      embudo: b.funnel || null,
      segundo_del_video: Math.round(Number(second) || 0),
      anuncio: row.utm_content,
    });
  }
  return new NextResponse(null, { status: 204, headers: CORS });
}
