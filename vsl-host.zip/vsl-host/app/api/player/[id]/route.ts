import { NextResponse } from 'next/server';
import { supabaseAdmin } from '@/lib/supabase';
import { hlsUrl, thumbUrl, playbackId } from '@/lib/cloudflare';
import { evergreenSessions } from '@/lib/evergreen';

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, OPTIONS',
  'Cache-Control': 'private, no-store',
};

type Row = Record<string, any>;

/** Comprueba que la página que pide el vídeo está en la lista de dominios permitidos. */
function domainAllowed(v: Row, req: Request) {
  const list = String(v.allowed_domains || '')
    .split(/[\s,]+/)
    .map((d) => d.trim().toLowerCase().replace(/^https?:\/\//, '').replace(/\/.*$/, ''))
    .filter(Boolean);
  if (!list.length) return true;
  const app = (process.env.NEXT_PUBLIC_APP_URL || '').replace(/^https?:\/\//, '');
  const src = req.headers.get('origin') || req.headers.get('referer') || '';
  let host = '';
  try { host = new URL(src).host.toLowerCase(); } catch { return false; }
  if (host === app) return true; // vista previa del panel
  return list.some((d) => host === d || host.endsWith('.' + d));
}

async function publicConfig(v: Row) {
  const dur = v.duration ? Number(v.duration) : null;
  const pid = await playbackId(v.stream_uid, !!v.protected, Math.round((dur || 3600) + 6 * 3600));
  const cfg: Record<string, unknown> = {
    id: v.id,
    hls: hlsUrl(pid),
    poster: thumbUrl(pid, Number(v.thumbnail_time) || 1),
    duration: dur,
    aspect: v.aspect,
    color: v.color,
    autoplay: v.autoplay_mode || (v.autoplay_muted ? 'always' : 'off'),
    unmuteTitle: v.unmute_title,
    unmuteSubtitle: v.unmute_subtitle,
    fastProgress: v.fast_progress,
    barHeight: v.bar_height ?? 6,
    allowPause: v.allow_pause,
    resume: v.resume_enabled,
    resumeDays: v.resume_days ?? 30,
    fullscreen: v.show_fullscreen,
    revealAt: v.reveal_at != null ? Number(v.reveal_at) : null,
    cta:
      v.cta_at != null && v.cta_text && v.cta_url
        ? { at: Number(v.cta_at), text: v.cta_text, url: v.cta_url, style: v.cta_style || {}, exitFullscreen: v.cta_exit_fullscreen }
        : null,
    metaEvents: v.meta_events,
    protect: !!v.protected,
    gate: v.gate?.enabled ? v.gate : null,
    questions: Array.isArray(v.questions) ? v.questions : [],
    mode: v.mode || 'vsl',
  };
  if (v.mode === 'evergreen' && dur) {
    cfg.live = { ...evergreenSessions(v.evergreen || {}, dur), labels: v.evergreen?.labels || {} };
  }
  return cfg;
}

export async function OPTIONS() {
  return new NextResponse(null, { status: 204, headers: CORS });
}

export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const nf = () => NextResponse.json({ error: 'not_found' }, { status: 404, headers: CORS });
  if (!/^[0-9a-f-]{36}$/i.test(id)) return nf();
  const sb = supabaseAdmin();

  const { data: video } = await sb.from('videos').select('*').eq('id', id).maybeSingle();
  if (video) {
    if (!domainAllowed(video, req)) return NextResponse.json({ error: 'domain' }, { status: 403, headers: CORS });
    return NextResponse.json({ type: 'video', video: await publicConfig(video) }, { headers: CORS });
  }

  const { data: test } = await sb.from('ab_tests').select('*').eq('id', id).maybeSingle();
  if (test) {
    const { data: vids } = await sb.from('videos').select('*').in('id', [test.video_a, test.video_b]);
    const a = vids?.find((x) => x.id === test.video_a);
    const b = vids?.find((x) => x.id === test.video_b);
    if (!a || !b) return nf();
    if (!domainAllowed(a, req) || !domainAllowed(b, req)) return NextResponse.json({ error: 'domain' }, { status: 403, headers: CORS });
    const split = !test.active && test.winner ? (test.winner === 'A' ? 1 : 0) : Number(test.split);
    return NextResponse.json(
      { type: 'test', testId: test.id, split, variants: { A: await publicConfig(a), B: await publicConfig(b) } },
      { headers: CORS }
    );
  }
  return nf();
}
