import { NextResponse } from 'next/server';
import { requireUser, supabaseAdmin } from '@/lib/supabase';
import { createTusUpload } from '@/lib/cloudflare';

/**
 * Punto de creación tus: el navegador pide aquí la subida, nosotros la abrimos en
 * Cloudflare Stream y devolvemos la URL de Cloudflare. El archivo va directo del
 * navegador a Cloudflare (no pasa por Vercel), así que no hay límite de tamaño.
 */
export async function POST(req: Request) {
  const { user } = await requireUser();
  if (!user) return new NextResponse('No autorizado', { status: 401 });

  const length = req.headers.get('upload-length');
  const meta = req.headers.get('upload-metadata') || '';
  if (!length) return new NextResponse('Falta Upload-Length', { status: 400 });

  // Nombre del archivo desde los metadatos tus (base64)
  let name = 'Nuevo vídeo';
  const m = meta.split(',').map((p) => p.trim().split(' ')).find(([k]) => k === 'name' || k === 'filename');
  if (m?.[1]) name = Buffer.from(m[1], 'base64').toString('utf8').replace(/\.[^.]+$/, '');

  // Metadatos para Cloudflare: nombre del vídeo y duración máxima (4 h)
  const cfMeta = [`name ${Buffer.from(name).toString('base64')}`, `maxDurationSeconds ${Buffer.from('14400').toString('base64')}`].join(',');

  try {
    const { location, uid } = await createTusUpload(length, cfMeta);
    const { data, error } = await supabaseAdmin()
      .from('videos')
      .insert({ owner_id: user.id, name, stream_uid: uid, status: 'processing' })
      .select('id')
      .single();
    if (error) throw error;
    return new NextResponse(null, {
      status: 201,
      headers: {
        Location: location,
        'Tus-Resumable': '1.0.0',
        'X-Video-Id': data.id,
        'Access-Control-Expose-Headers': 'Location, X-Video-Id',
      },
    });
  } catch (e: any) {
    return new NextResponse(String(e?.message || e), { status: 500 });
  }
}
