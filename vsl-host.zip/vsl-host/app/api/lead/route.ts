import { NextResponse } from 'next/server';
import { supabaseAdmin } from '@/lib/supabase';
import { notify, addToGetResponse } from '@/lib/notify';

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type',
};

export async function OPTIONS() {
  return new NextResponse(null, { status: 204, headers: CORS });
}

/** Formulario dentro del vídeo (play gate). */
export async function POST(req: Request) {
  let b: any;
  try { b = JSON.parse(await req.text()); } catch { return new NextResponse(null, { status: 400, headers: CORS }); }
  const vid = String(b.vid || '');
  if (!/^[0-9a-f-]{36}$/i.test(vid)) return new NextResponse(null, { status: 400, headers: CORS });

  const sb = supabaseAdmin();
  const { data: video } = await sb.from('videos').select('id, owner_id, name, notify, webhook_url').eq('id', vid).maybeSingle();
  if (!video) return new NextResponse(null, { status: 404, headers: CORS });

  // Limpia los campos: máximo 20 y 500 caracteres cada uno
  const data: Record<string, string> = {};
  Object.entries(b.data || {}).slice(0, 20).forEach(([k, v]) => { data[String(k).slice(0, 60)] = String(v ?? '').slice(0, 500); });
  const email = (data.email || '').trim().toLowerCase() || null;
  const name = data.name?.trim() || null;
  const phone = data.phone?.trim() || null;
  const sid = String(b.sid || '').slice(0, 64) || null;

  await sb.from('leads').insert({
    owner_id: video.owner_id,
    video_id: vid,
    session_id: sid,
    name, email, phone,
    data,
    page_url: String(b.url || '').slice(0, 500) || null,
  });
  if (sid) await sb.from('views').update({ lead: true }).eq('session_id', sid);

  const { data: s } = await sb.from('settings').select('*').eq('owner_id', video.owner_id).maybeSingle();
  await Promise.all([
    notify('lead', video, s, { ...data, pagina: b.url || null }),
    addToGetResponse(s, { email, name }),
  ]);
  return new NextResponse(null, { status: 204, headers: CORS });
}
