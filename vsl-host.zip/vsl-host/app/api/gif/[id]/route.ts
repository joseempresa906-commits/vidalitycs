import { NextResponse } from 'next/server';
import { supabaseAdmin } from '@/lib/supabase';
import { gifUrl, playbackId } from '@/lib/cloudflare';

/**
 * GIF animado para emails. URL estable: /api/gif/ID?s=10&d=4&h=360
 * Redirige a Cloudflare (con firma nueva si el vídeo está protegido).
 */
export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!/^[0-9a-f-]{36}$/i.test(id)) return new NextResponse('No encontrado', { status: 404 });
  const { data: v } = await supabaseAdmin().from('videos').select('stream_uid, protected, duration').eq('id', id).maybeSingle();
  if (!v) return new NextResponse('No encontrado', { status: 404 });

  const q = new URL(req.url).searchParams;
  const s = Math.max(0, Number(q.get('s')) || 0);
  const d = Math.min(15, Math.max(1, Number(q.get('d')) || 4));
  const h = Math.min(720, Math.max(120, Number(q.get('h')) || 360));
  const pid = await playbackId(v.stream_uid, !!v.protected, 3600);

  return NextResponse.redirect(gifUrl(pid, s, d, h), {
    status: 302,
    headers: { 'Cache-Control': 'public, max-age=600' },
  });
}
