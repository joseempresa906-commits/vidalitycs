import { NextResponse } from 'next/server';
import { supabaseAdmin } from '@/lib/supabase';
import { sendCapiEvent } from '@/lib/meta';
import { notify } from '@/lib/notify';

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type',
};

const THRESHOLDS = [25, 50, 75, 95];
const UUID = /^[0-9a-f-]{36}$/i;

export async function OPTIONS() {
  return new NextResponse(null, { status: 204, headers: CORS });
}

/**
 * Recibe los latidos del player. Se envía como text/plain (sendBeacon) para evitar preflight.
 * ev: load | start | play | progress | cta | click | answer
 */
export async function POST(req: Request) {
  let b: any;
  try {
    b = JSON.parse(await req.text());
  } catch {
    return new NextResponse(null, { status: 400, headers: CORS });
  }
  const sid = String(b.sid || '').slice(0, 64);
  const vid = String(b.vid || '');
  if (!sid || !UUID.test(vid)) return new NextResponse(null, { status: 400, headers: CORS });

  const sb = supabaseAdmin();
  const { data: video } = await sb
    .from('videos')
    .select('id, owner_id, duration, meta_events, name, notify, webhook_url')
    .eq('id', vid)
    .maybeSingle();
  if (!video) return new NextResponse(null, { status: 404, headers: CORS });

  const t = Math.max(0, Number(b.t) || 0);
  const dur = Number(b.dur) || Number(video.duration) || null;
  const ev = String(b.ev || 'progress');

  const { data: row } = await sb.from('views').select('*').eq('session_id', sid).maybeSingle();

  const patch: Record<string, any> = { updated_at: new Date().toISOString() };
  if (dur) patch.duration = dur;
  if (ev === 'start') patch.started = true;
  if (ev === 'play') { patch.started = true; patch.played = true; }
  if (ev === 'cta') patch.reached_cta = true;
  if (ev === 'click') patch.click_second = Number(b.ct) || t;
  if (ev === 'answer' && b.answer) {
    const a = { q: String(b.answer.q || '').slice(0, 200), a: String(b.answer.a || '').slice(0, 200), t: Number(b.answer.t) || t };
    patch.answers = [...(row?.answers || []), a];
  }
  const played = patch.played || row?.played;
  if (played && ['progress', 'cta', 'play', 'click', 'answer'].includes(ev)) {
    patch.max_second = Math.max(Number(row?.max_second) || 0, t);
  }

  const already: number[] = row?.thresholds || [];
  const newHits: number[] = [];
  if (played && dur) {
    const pct = ((patch.max_second ?? Number(row?.max_second) ?? 0) / dur) * 100;
    for (const th of THRESHOLDS) if (pct >= th && !already.includes(th)) newHits.push(th);
    if (newHits.length) patch.thresholds = [...already, ...newHits];
  }
  const ctaNew = ev === 'cta' && !row?.reached_cta;
  const playNew = ev === 'play' && !row?.played;

  const utm = b.utm || {};
  const pageUrl = String(b.url || '').slice(0, 500) || null;
  if (!row) {
    await sb.from('views').insert({
      session_id: sid,
      video_id: vid,
      test_id: UUID.test(b.tid || '') ? b.tid : null,
      variant: b.variant === 'A' || b.variant === 'B' ? b.variant : null,
      utm_source: utm.utm_source?.slice(0, 200) || null,
      utm_medium: utm.utm_medium?.slice(0, 200) || null,
      utm_campaign: utm.utm_campaign?.slice(0, 200) || null,
      utm_content: utm.utm_content?.slice(0, 200) || null,
      utm_term: utm.utm_term?.slice(0, 200) || null,
      referrer: String(b.ref || '').slice(0, 500) || null,
      page_url: pageUrl,
      device: b.dev === 'mobile' ? 'mobile' : 'desktop',
      country: req.headers.get('x-vercel-ip-country'),
      ...patch,
    });
  } else {
    await sb.from('views').update(patch).eq('id', row.id);
  }

  const needSettings = newHits.length || ctaNew || playNew;
  if (!needSettings) return new NextResponse(null, { status: 204, headers: CORS });
  const { data: s } = await sb.from('settings').select('*').eq('owner_id', video.owner_id).maybeSingle();

  const jobs: Promise<unknown>[] = [];
  const info = {
    pagina: pageUrl,
    fuente: utm.utm_source || null,
    anuncio: utm.utm_content || null,
    pais: req.headers.get('x-vercel-ip-country'),
    dispositivo: b.dev,
  };
  if (playNew) jobs.push(notify('play', video, s, info));
  if (ctaNew) jobs.push(notify('pitch', video, s, { ...info, segundo: Math.round(t) }));

  // API de Conversiones (servidor) — se deduplica con el fbq del navegador por event_id
  if ((newHits.length || ctaNew) && video.meta_events && s?.meta_pixel_id && s?.meta_capi_token) {
    const common = {
      pixelId: s.meta_pixel_id,
      token: s.meta_capi_token,
      testCode: s.meta_test_event_code,
      url: b.url,
      ip: (req.headers.get('x-forwarded-for') || '').split(',')[0].trim() || null,
      ua: req.headers.get('user-agent'),
      fbp: b.fbp || null,
      fbc: b.fbc || null,
      externalId: sid,
      custom: { video_id: vid, video_name: video.name },
    };
    newHits.forEach((th) => jobs.push(sendCapiEvent({ ...common, eventName: `VSL_${th}`, eventId: `${sid}_${th}` })));
    if (ctaNew) jobs.push(sendCapiEvent({ ...common, eventName: 'VSL_Pitch', eventId: `${sid}_pitch` }));
  }
  await Promise.all(jobs);

  return new NextResponse(null, { status: 204, headers: CORS });
}
