import { supabaseAdmin } from '@/lib/supabase';
import { dayKey, safeTz } from '@/lib/tz';

/**
 * CSV diario por vídeo para Google Sheets / Looker Studio.
 * En Google Sheets: =IMPORTDATA("https://TU-APP/api/export/TOKEN")
 * Parámetro opcional ?days=90
 */
export async function GET(req: Request, { params }: { params: Promise<{ token: string }> }) {
  const { token } = await params;
  if (!/^[0-9a-f-]{36}$/i.test(token)) return new Response('No encontrado', { status: 404 });
  const sb = supabaseAdmin();
  const { data: s } = await sb.from('settings').select('owner_id, timezone').eq('export_token', token).maybeSingle();
  if (!s) return new Response('No encontrado', { status: 404 });
  const tz = safeTz(s.timezone);

  const days = Math.min(365, Math.max(1, Number(new URL(req.url).searchParams.get('days')) || 90));
  const from = new Date(Date.now() - days * 86400000).toISOString();
  const { data: videos } = await sb.from('videos').select('id, name, duration').eq('owner_id', s.owner_id);
  const ids = (videos || []).map((v) => v.id);
  if (!ids.length) return csv('fecha,video_id,video,cargas,reproducciones,play_rate,visionado_medio_pct,llegan_pitch,conversiones,ingresos,leads\n');

  const rows: any[] = [];
  for (let page = 0; page < 50; page++) {
    const { data } = await sb
      .from('views')
      .select('video_id, created_at, played, max_second, duration, reached_cta, converted, conversion_value, lead')
      .in('video_id', ids)
      .gte('created_at', from)
      .range(page * 1000, page * 1000 + 999);
    if (!data?.length) break;
    rows.push(...data);
    if (data.length < 1000) break;
  }

  const agg = new Map<string, any>();
  for (const r of rows) {
    const k = `${dayKey(r.created_at, tz)}|${r.video_id}`;
    const a = agg.get(k) || { loads: 0, plays: 0, pctSum: 0, pitch: 0, conv: 0, rev: 0, leads: 0 };
    a.loads++;
    if (r.played) {
      a.plays++;
      const d = Number(r.duration) || 0;
      a.pctSum += d ? Math.min(1, Number(r.max_second) / d) : 0;
      if (r.reached_cta) a.pitch++;
    }
    if (r.converted) { a.conv++; a.rev += Number(r.conversion_value) || 0; }
    if (r.lead) a.leads++;
    agg.set(k, a);
  }
  const name = (id: string) => (videos || []).find((v) => v.id === id)?.name || '';
  const esc = (x: string) => `"${x.replace(/"/g, '""')}"`;
  let out = 'fecha,video_id,video,cargas,reproducciones,play_rate,visionado_medio_pct,llegan_pitch,conversiones,ingresos,leads\n';
  [...agg.entries()]
    .sort(([a], [b]) => (a < b ? 1 : -1))
    .forEach(([k, a]) => {
      const [day, vid] = k.split('|');
      out += [
        day, vid, esc(name(vid)), a.loads, a.plays,
        a.loads ? (a.plays / a.loads).toFixed(4) : 0,
        a.plays ? ((a.pctSum / a.plays) * 100).toFixed(1) : 0,
        a.pitch, a.conv, a.rev.toFixed(2), a.leads,
      ].join(',') + '\n';
    });
  return csv(out);
}

function csv(body: string) {
  return new Response(body, { headers: { 'Content-Type': 'text/csv; charset=utf-8', 'Cache-Control': 'no-store' } });
}
