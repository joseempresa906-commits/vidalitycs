import Link from 'next/link';
import { notFound, redirect } from 'next/navigation';
import Shell from '@/components/Shell';
import RetentionChart from '@/components/RetentionChart';
import DailyChart from '@/components/DailyChart';
import CopyBox from '@/components/CopyBox';
import Preview from '@/components/Preview';
import ConfirmButton from '@/components/ConfirmButton';
import QuestionsEditor from '@/components/QuestionsEditor';
import GateFieldsEditor from '@/components/GateFieldsEditor';
import GifBuilder from '@/components/GifBuilder';
import { requireUser, getSettings } from '@/lib/supabase';
import { getStreamVideo } from '@/lib/cloudflare';
import { safeTz } from '@/lib/tz';
import {
  summarize, groupBy, retention, conversionBars, daily, answerStats, fetchAll,
  pct, mmss, money, rangeFrom, VIEW_COLS, type ViewRow,
} from '@/lib/stats';
import { updateVideo, deleteVideo, copySettings } from '@/app/actions';

export const dynamic = 'force-dynamic';

const DAYS = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];
const t = (v: any) => (v != null && v !== '' ? mmss(Number(v)) : '');

export default async function VideoPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ d?: string; by?: string; ok?: string; err?: string }>;
}) {
  const { id } = await params;
  const { d = '30', by = 'utm_content', ok, err } = await searchParams;
  const { sb, user } = await requireUser();
  if (!user) redirect('/login');
  const settings = await getSettings(sb, user.id);
  const tz = safeTz(settings.timezone);

  let { data: v } = await sb.from('videos').select('*').eq('id', id).maybeSingle();
  if (!v) notFound();

  if (v.status !== 'ready') {
    const cf = await getStreamVideo(v.stream_uid);
    if (cf?.readyToStream) {
      const w = cf.input?.width, h = cf.input?.height;
      const aspect = w && h ? (h > w * 1.5 ? '9:16' : Math.abs(w - h) < 10 ? '1:1' : h > w ? '4:5' : '16:9') : v.aspect;
      const { data } = await sb.from('videos').update({ status: 'ready', duration: cf.duration, aspect }).eq('id', id).select('*').single();
      v = data;
    } else if (cf?.status?.state === 'error') {
      await sb.from('videos').update({ status: 'error' }).eq('id', id);
    }
  }

  const from = rangeFrom(d, tz);
  const [views, { data: others }] = await Promise.all([
    fetchAll<ViewRow>((a, b) => sb.from('views').select(VIEW_COLS).eq('video_id', id).gte('created_at', from).range(a, b)),
    sb.from('videos').select('id,name').neq('id', id).order('created_at', { ascending: false }),
  ]);
  const dur = Number(v.duration || 0);
  const s = summarize(views, dur);
  const curve = retention(views, dur);
  const bars = conversionBars(views, dur);
  const days = daily(views, tz);
  const answers = answerStats(views);
  const byKey = (r: ViewRow) => ((r as any)[by] as string) || (by === 'device' ? 'desconocido' : by === 'funnel' ? '(sin embudo)' : '(sin UTM)');
  const groups = groupBy(by === 'funnel' ? views.filter((r) => r.converted) : views, byKey, dur);

  const app = process.env.NEXT_PUBLIC_APP_URL || '';
  const embed = `<div data-vsl="${v.id}"></div>\n<script async src="${app}/embed.js"></script>`;
  const convSnippet = `<script async src="${app}/convert.js" data-value="97" data-funnel="Nombre del embudo"></script>`;
  const markers = [
    ...(v.reveal_at != null ? [{ s: Number(v.reveal_at), label: 'Pitch' }] : []),
    ...(v.cta_at != null && v.cta_at !== v.reveal_at ? [{ s: Number(v.cta_at), label: 'Botón' }] : []),
    ...(v.gate?.enabled && Number(v.gate.at) > 0 ? [{ s: Number(v.gate.at), label: 'Formulario' }] : []),
    ...((v.questions || []) as any[]).map((q, i) => ({ s: Number(q.at), label: `P${i + 1}` })),
  ];
  const save = updateVideo.bind(null, v.id);
  const del = deleteVideo.bind(null, v.id);
  const copy = copySettings.bind(null, v.id);
  const cs = v.cta_style || {};
  const ev = v.evergreen || {};
  const gate = v.gate || {};
  const nt = v.notify || {};
  const tab = (k: string, label: string) => <Link className={d === k ? 'on' : ''} href={`?d=${k}&by=${by}`}>{label}</Link>;
  const byTab = (k: string, label: string) => <Link className={by === k ? 'on' : ''} href={`?d=${d}&by=${k}`}>{label}</Link>;

  return (
    <Shell>
      <div className="row between" style={{ marginBottom: 18 }}>
        <div>
          <h1>{v.name}</h1>
          <p className="sub" style={{ margin: 0 }}>
            {v.status === 'ready' ? `${mmss(dur)} · ${v.aspect}${v.mode === 'evergreen' ? ' · Webinar evergreen' : ''}${v.protected ? ' · Protegido' : ''}` : v.status === 'error' ? 'Error al procesar en Cloudflare' : 'Procesando… recarga en un minuto'}
          </p>
        </div>
        <div className="tabs">{tab('1', 'Hoy')}{tab('7', '7 días')}{tab('30', '30 días')}{tab('90', '90 días')}{tab('all', 'Todo')}</div>
      </div>
      {ok && <p className="ok">Guardado.</p>}
      {err && <p className="err">{err}</p>}

      <div className="kpis">
        <div className="kpi"><small>Cargas</small><b>{s.loads}</b></div>
        <div className="kpi"><small>Reproducciones</small><b>{s.plays}</b><small>{pct(s.playRate)} play rate</small></div>
        <div className="kpi"><small>Visionado medio</small><b>{pct(s.avgPct)}</b><small>{mmss(s.avgSec)}</small></div>
        <div className="kpi"><small>Llegan al pitch</small><b>{pct(s.pitchRate)}</b><small>{s.pitch} personas</small></div>
        <div className="kpi"><small>Conversiones</small><b>{s.conv}</b><small>{pct(s.convRate)} de reprod.</small></div>
        <div className="kpi"><small>Ingresos</small><b>{money(s.revenue)}</b><small>{s.plays ? money(s.revenue / s.plays) : 0} por reprod.</small></div>
        <div className="kpi"><small>Leads</small><b>{s.leads}</b></div>
      </div>

      <div className="card">
        <h2>Retención {bars.some((b) => b > 0) && <span className="hint">· barras verdes = ventas en ese momento del vídeo</span>}</h2>
        <RetentionChart duration={dur} series={[{ name: 'Retención', color: v.color || '#E11D48', data: curve }]} markers={markers} bars={bars} />
      </div>

      {d !== '1' && (
        <div className="card">
          <h2>Por día <span className="hint">({tz})</span></h2>
          <DailyChart data={days} />
        </div>
      )}

      <div className="card">
        <div className="row between" style={{ marginBottom: 12 }}>
          <h2 style={{ margin: 0 }}>Desglose</h2>
          <div className="tabs">
            {byTab('utm_content', 'Anuncio')}
            {byTab('utm_campaign', 'Campaña')}
            {byTab('utm_source', 'Fuente')}
            {byTab('device', 'Dispositivo')}
            {byTab('funnel', 'Embudo')}
          </div>
        </div>
        <table>
          <thead><tr><th>{by}</th><th>Cargas</th><th>Reprod.</th><th>Play rate</th><th>Visionado</th><th>Pitch</th><th>Conv.</th><th>Conv. %</th><th>Ingresos</th></tr></thead>
          <tbody>
            {groups.map((g) => (
              <tr key={g.key}>
                <td>{g.key}</td><td>{g.loads}</td><td>{g.plays}</td><td>{pct(g.playRate)}</td><td>{pct(g.avgPct)}</td>
                <td>{pct(g.pitchRate)}</td><td>{g.conv}</td><td>{pct(g.convRate)}</td><td>{money(g.revenue)}</td>
              </tr>
            ))}
            {!groups.length && <tr><td colSpan={9} className="hint">Sin datos</td></tr>}
          </tbody>
        </table>
      </div>

      {answers.length > 0 && (
        <div className="card">
          <h2>Respuestas a las preguntas</h2>
          {answers.map((q) => (
            <div key={q.q} style={{ marginBottom: 14 }}>
              <b>{q.q}</b> <span className="hint">({q.total} respuestas)</span>
              {q.options.map((o) => (
                <div key={o.a} className="row" style={{ marginTop: 6 }}>
                  <span style={{ width: 160 }}>{o.a}</span>
                  <div className="progress" style={{ flex: 1 }}><i style={{ width: `${o.pct * 100}%` }} /></div>
                  <span style={{ width: 90, textAlign: 'right' }}>{pct(o.pct)} ({o.n})</span>
                </div>
              ))}
            </div>
          ))}
        </div>
      )}

      <div className="grid g2">
        <div>
          <div className="card">
            <h2>Código para tu landing</h2>
            <CopyBox text={embed} />
            <p className="hint" style={{ marginTop: 12 }}>
              Secciones que aparecen en el pitch: <code>class=&quot;vsl-reveal&quot;</code> o <code>data-vsl-reveal=&quot;125&quot;</code>.
              Los enlaces dentro de esas secciones (o con <code>data-vsl-link</code>) llevan la sesión para atribuir la venta.
            </p>
          </div>
          <div className="card">
            <h2>Conversiones</h2>
            <p className="hint">Pega esto en tu página de gracias. Cambia el valor y el nombre del embudo.</p>
            <CopyBox text={convSnippet} />
          </div>
          <div className="card">
            <h2>Vista previa</h2>
            {v.status === 'ready' ? <Preview id={v.id} version={JSON.stringify(v).length + String(v.color)} /> : <p className="hint">Disponible cuando termine de procesar.</p>}
          </div>
          <div className="card">
            <h2>GIF para emails</h2>
            {v.status === 'ready' ? <GifBuilder id={v.id} app={app} /> : <p className="hint">Disponible cuando termine de procesar.</p>}
          </div>
          {!!others?.length && (
            <form className="card" action={copy}>
              <h2>Copiar ajustes de otro vídeo</h2>
              <div className="row">
                <select name="from" style={{ flex: 1 }}>{others.map((o) => <option key={o.id} value={o.id}>{o.name}</option>)}</select>
                <button className="btn ghost">Copiar</button>
              </div>
            </form>
          )}
        </div>

        <form className="card" action={save}>
          <h2>Ajustes</h2>
          <div className="field"><label>Nombre</label><input type="text" name="name" defaultValue={v.name} /></div>
          <div className="grid g3" style={{ gap: 12 }}>
            <div className="field"><label>Formato</label>
              <select name="aspect" defaultValue={v.aspect}><option>16:9</option><option>9:16</option><option>1:1</option><option>4:5</option></select>
            </div>
            <div className="field"><label>Color</label><input type="text" name="color" defaultValue={v.color} /></div>
            <div className="field"><label>Miniatura (seg.)</label><input type="text" name="thumbnail_time" defaultValue={v.thumbnail_time} /></div>
          </div>

          <div className="section">
            <h2>Reproducción</h2>
            <div className="field"><label>Autoplay silenciado con aviso de sonido</label>
              <select name="autoplay_mode" defaultValue={v.autoplay_mode || 'always'}>
                <option value="always">En móvil y ordenador</option>
                <option value="mobile">Solo en móvil</option>
                <option value="desktop">Solo en ordenador</option>
                <option value="off">Nunca (botón de play)</option>
              </select>
            </div>
            <div className="grid g2" style={{ gap: 12 }}>
              <div className="field"><label>Texto aviso</label><input type="text" name="unmute_title" defaultValue={v.unmute_title} /></div>
              <div className="field"><label>Subtexto aviso</label><input type="text" name="unmute_subtitle" defaultValue={v.unmute_subtitle} /></div>
            </div>
            <div className="grid g2" style={{ gap: 12 }}>
              <label className="check"><input type="checkbox" name="fast_progress" defaultChecked={v.fast_progress} /> Barra de progreso rápida</label>
              <div className="field row"><label style={{ margin: 0 }}>Grosor barra (px)</label><input type="number" name="bar_height" defaultValue={v.bar_height ?? 6} min={2} max={20} style={{ width: 80 }} /></div>
            </div>
            <label className="check"><input type="checkbox" name="allow_pause" defaultChecked={v.allow_pause} /> Permitir pausar tocando el vídeo</label>
            <label className="check"><input type="checkbox" name="show_fullscreen" defaultChecked={v.show_fullscreen ?? true} /> Botón de pantalla completa</label>
            <div className="row">
              <label className="check" style={{ margin: 0 }}><input type="checkbox" name="resume_enabled" defaultChecked={v.resume_enabled} /> Ofrecer &quot;Continuar viendo&quot; durante</label>
              <input type="number" name="resume_days" defaultValue={v.resume_days ?? 30} min={1} style={{ width: 80 }} /> días
            </div>
          </div>

          <div className="section">
            <h2>Pitch y botón</h2>
            <div className="field">
              <label>Mostrar secciones .vsl-reveal en <span className="hint">(seg. o mm:ss)</span></label>
              <input type="text" name="reveal_at" defaultValue={t(v.reveal_at)} placeholder="12:30" />
            </div>
            <div className="grid g3" style={{ gap: 12 }}>
              <div className="field"><label>Botón aparece en</label><input type="text" name="cta_at" defaultValue={t(v.cta_at)} placeholder="12:30" /></div>
              <div className="field"><label>Texto botón</label><input type="text" name="cta_text" defaultValue={v.cta_text || ''} placeholder="Quiero acceder" /></div>
              <div className="field"><label>URL botón</label><input type="text" name="cta_url" defaultValue={v.cta_url || ''} placeholder="https://..." /></div>
            </div>
            <div className="grid g3" style={{ gap: 12 }}>
              <div className="field"><label>Fondo</label><input type="text" name="cta_bg" defaultValue={cs.bg || ''} placeholder={v.color} /></div>
              <div className="field"><label>Texto</label><input type="text" name="cta_fg" defaultValue={cs.fg || ''} placeholder="#ffffff" /></div>
              <div className="field"><label>Tamaño</label>
                <select name="cta_size" defaultValue={cs.size || 'm'}><option value="s">Pequeño</option><option value="m">Mediano</option><option value="l">Grande</option></select>
              </div>
              <div className="field"><label>Forma</label>
                <select name="cta_shape" defaultValue={cs.shape || 'rounded'}><option value="square">Recto</option><option value="rounded">Redondeado</option><option value="pill">Píldora</option></select>
              </div>
              <div className="field"><label>Animación</label>
                <select name="cta_anim" defaultValue={cs.anim || 'none'}><option value="none">Ninguna</option><option value="pulse">Latido</option><option value="shake">Sacudida</option></select>
              </div>
              <label className="check" style={{ alignSelf: 'end' }}><input type="checkbox" name="cta_full" defaultChecked={!!cs.full} /> Ancho completo</label>
            </div>
            <label className="check"><input type="checkbox" name="cta_exit_fullscreen" defaultChecked={v.cta_exit_fullscreen ?? true} /> Salir de pantalla completa cuando aparece el botón</label>
          </div>

          <div className="section">
            <h2>Formulario dentro del vídeo</h2>
            <label className="check"><input type="checkbox" name="gate_enabled" defaultChecked={!!gate.enabled} /> Activar</label>
            <div className="grid g2" style={{ gap: 12 }}>
              <div className="field"><label>Aparece en <span className="hint">(0 = antes de empezar)</span></label><input type="text" name="gate_at" defaultValue={gate.at ? t(gate.at) : '0'} /></div>
              <div className="field"><label>Texto del botón</label><input type="text" name="gate_button" defaultValue={gate.button || ''} placeholder="Seguir viendo" /></div>
            </div>
            <div className="field"><label>Título</label><input type="text" name="gate_title" defaultValue={gate.title || ''} placeholder="Introduce tus datos para seguir viendo" /></div>
            <div className="field"><label>Subtítulo</label><input type="text" name="gate_subtitle" defaultValue={gate.subtitle || ''} /></div>
            <div className="field"><label>Campos</label><GateFieldsEditor initial={gate.fields || []} /></div>
            <div className="row">
              <label className="check" style={{ margin: 0 }}><input type="checkbox" name="gate_skippable" defaultChecked={!!gate.skippable} /> Se puede saltar, texto:</label>
              <input type="text" name="gate_skip_text" defaultValue={gate.skipText || ''} placeholder="Saltar" style={{ width: 160 }} />
            </div>
          </div>

          <div className="section">
            <h2>Preguntas interactivas</h2>
            <p className="hint">El vídeo se para, el espectador elige y según la respuesta sigue, salta, cambia a otro vídeo o va a una página.</p>
            <QuestionsEditor initial={v.questions || []} videos={(others || []) as any} />
          </div>

          <div className="section">
            <h2>Modo</h2>
            <div className="field">
              <select name="mode" defaultValue={v.mode || 'vsl'}>
                <option value="vsl">VSL normal</option>
                <option value="evergreen">Webinar evergreen (simula directo)</option>
              </select>
            </div>
            <p className="hint">En modo webinar todos ven el mismo punto del vídeo según la hora, sin pausar ni retroceder. Antes de la sesión se muestra una cuenta atrás.</p>
            <div className="grid g2" style={{ gap: 12 }}>
              <div className="field"><label>Horas de sesión</label><input type="text" name="ev_times" defaultValue={(ev.times || []).join(', ')} placeholder="19:00, 21:30" /></div>
              <div className="field"><label>O cada X minutos</label><input type="number" name="ev_every" defaultValue={ev.every_minutes || ''} placeholder="15" /></div>
            </div>
            <div className="field"><label>Días</label>
              <div className="daypick">
                {DAYS.map((n, i) => (
                  <label key={i}><input type="checkbox" name={`ev_day_${i}`} defaultChecked={!ev.days?.length || ev.days.includes(i)} /> {n}</label>
                ))}
              </div>
            </div>
            <div className="field"><label>Zona horaria</label><input type="text" name="ev_tz" defaultValue={ev.tz || tz} /></div>
            <div className="grid g3" style={{ gap: 12 }}>
              <div className="field"><label>Texto cuenta atrás</label><input type="text" name="ev_label_countdown" defaultValue={ev.labels?.countdown || ''} placeholder="La sesión empieza en" /></div>
              <div className="field"><label>Texto al terminar</label><input type="text" name="ev_label_ended" defaultValue={ev.labels?.ended || ''} placeholder="Esta sesión ha terminado" /></div>
              <div className="field"><label>Etiqueta directo</label><input type="text" name="ev_label_live" defaultValue={ev.labels?.live || ''} placeholder="EN DIRECTO" /></div>
            </div>
          </div>

          <div className="section">
            <h2>Protección</h2>
            <label className="check"><input type="checkbox" name="protected" defaultChecked={!!v.protected} /> Proteger contra descargas (enlaces firmados que caducan)</label>
            <div className="field">
              <label>Solo se puede ver en estos dominios <span className="hint">(vacío = en cualquiera)</span></label>
              <input type="text" name="allowed_domains" defaultValue={v.allowed_domains || ''} placeholder="midominio.com, otrodominio.com" />
            </div>
            <p className="hint">Impide descargar el vídeo y usarlo en otras webs. Nadie puede impedir al 100% que alguien grabe su pantalla.</p>
          </div>

          <div className="section">
            <h2>Avisos</h2>
            <div className="daypick">
              <label><input type="checkbox" name="notify_play" defaultChecked={!!nt.play} /> Alguien empieza a verlo</label>
              <label><input type="checkbox" name="notify_pitch" defaultChecked={!!nt.pitch} /> Llega al pitch</label>
              <label><input type="checkbox" name="notify_lead" defaultChecked={!!nt.lead} /> Deja sus datos</label>
              <label><input type="checkbox" name="notify_conversion" defaultChecked={!!nt.conversion} /> Compra</label>
            </div>
            <div className="field" style={{ marginTop: 10 }}>
              <label>Webhook de este vídeo <span className="hint">(opcional; si no, usa el de Ajustes)</span></label>
              <input type="text" name="webhook_url" defaultValue={v.webhook_url || ''} placeholder="https://hook.make.com/..." />
            </div>
            <p className="hint">Los avisos van al email y al webhook configurados en Ajustes.</p>
          </div>

          <div className="section">
            <h2>Meta</h2>
            <label className="check"><input type="checkbox" name="meta_events" defaultChecked={v.meta_events} /> Enviar eventos VSL_25 / 50 / 75 / 95 y VSL_Pitch de este vídeo</label>
          </div>

          <div className="row between" style={{ marginTop: 18 }}>
            <button className="btn accent" type="submit">Guardar</button>
            <ConfirmButton action={del} label="Eliminar vídeo" question="¿Eliminar este vídeo y sus estadísticas? No se puede deshacer." />
          </div>
        </form>
      </div>
    </Shell>
  );
}
