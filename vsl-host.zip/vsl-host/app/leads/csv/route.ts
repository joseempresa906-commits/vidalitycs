import { requireUser } from '@/lib/supabase';
import { fetchAll } from '@/lib/stats';

export async function GET(req: Request) {
  const { sb, user } = await requireUser();
  if (!user) return new Response('No autorizado', { status: 401 });
  const filter = new URL(req.url).searchParams.get('v');
  const { data: videos } = await sb.from('videos').select('id,name');
  const leads = await fetchAll<any>((a, b) => {
    let q = sb.from('leads').select('*').order('created_at', { ascending: false }).range(a, b);
    if (filter) q = q.eq('video_id', filter);
    return q;
  });
  const keys = new Set<string>();
  leads.forEach((l) => Object.keys(l.data || {}).forEach((k) => !['name', 'email', 'phone'].includes(k) && keys.add(k)));
  const extra = [...keys];
  const esc = (x: unknown) => `"${String(x ?? '').replace(/"/g, '""')}"`;
  const head = ['fecha', 'nombre', 'email', 'telefono', ...extra, 'video', 'pagina'];
  const rows = leads.map((l) =>
    [l.created_at, l.name, l.email, l.phone, ...extra.map((k) => l.data?.[k]), videos?.find((v) => v.id === l.video_id)?.name, l.page_url]
      .map(esc)
      .join(',')
  );
  return new Response('﻿' + [head.join(','), ...rows].join('\n'), {
    headers: { 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': 'attachment; filename="leads.csv"' },
  });
}
