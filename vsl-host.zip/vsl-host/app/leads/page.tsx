import Link from 'next/link';
import { redirect } from 'next/navigation';
import Shell from '@/components/Shell';
import { requireUser, getSettings } from '@/lib/supabase';
import { safeTz } from '@/lib/tz';

export const dynamic = 'force-dynamic';

export default async function Leads({ searchParams }: { searchParams: Promise<{ v?: string }> }) {
  const { v: filter } = await searchParams;
  const { sb, user } = await requireUser();
  if (!user) redirect('/login');
  const tz = safeTz((await getSettings(sb, user.id)).timezone);
  const { data: videos } = await sb.from('videos').select('id,name');
  let q = sb.from('leads').select('*').order('created_at', { ascending: false }).limit(500);
  if (filter) q = q.eq('video_id', filter);
  const { data: leads } = await q;
  const name = (id: string) => videos?.find((x) => x.id === id)?.name || '—';
  const fmt = new Intl.DateTimeFormat('es-ES', { timeZone: tz, dateStyle: 'short', timeStyle: 'short' });
  const extra = (d: Record<string, string>) =>
    Object.entries(d || {}).filter(([k]) => !['name', 'email', 'phone'].includes(k)).map(([k, val]) => `${k}: ${val}`).join(' · ');

  return (
    <Shell>
      <div className="row between" style={{ marginBottom: 18 }}>
        <div>
          <h1>Leads</h1>
          <p className="sub" style={{ margin: 0 }}>Personas que han rellenado el formulario dentro de tus vídeos</p>
        </div>
        <a className="btn ghost" href={`/leads/csv${filter ? `?v=${filter}` : ''}`}>Descargar CSV</a>
      </div>
      <div className="tabs" style={{ marginBottom: 14, flexWrap: 'wrap' }}>
        <Link className={!filter ? 'on' : ''} href="/leads">Todos</Link>
        {videos?.map((x) => <Link key={x.id} className={filter === x.id ? 'on' : ''} href={`/leads?v=${x.id}`}>{x.name}</Link>)}
      </div>
      <div className="card">
        <table>
          <thead><tr><th>Fecha</th><th>Nombre</th><th>Email</th><th>Teléfono</th><th>Otros</th><th>Vídeo</th></tr></thead>
          <tbody>
            {leads?.map((l) => (
              <tr key={l.id}>
                <td>{fmt.format(new Date(l.created_at))}</td><td>{l.name}</td><td>{l.email}</td><td>{l.phone}</td>
                <td className="hint">{extra(l.data)}</td><td>{name(l.video_id)}</td>
              </tr>
            ))}
            {!leads?.length && <tr><td colSpan={6} className="hint">Aún no hay leads.</td></tr>}
          </tbody>
        </table>
      </div>
    </Shell>
  );
}
