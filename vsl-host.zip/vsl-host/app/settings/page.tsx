import { redirect } from 'next/navigation';
import Shell from '@/components/Shell';
import CopyBox from '@/components/CopyBox';
import { requireUser, getSettings } from '@/lib/supabase';
import { saveSettings, regenerateExportToken } from '@/app/actions';

export const dynamic = 'force-dynamic';

const ZONES = [
  'Europe/Madrid', 'Europe/Andorra', 'Atlantic/Canary', 'Europe/London', 'America/Mexico_City', 'America/Bogota',
  'America/Lima', 'America/Santiago', 'America/Argentina/Buenos_Aires', 'America/Caracas', 'America/Guatemala',
  'America/Santo_Domingo', 'America/New_York', 'America/Chicago', 'America/Denver', 'America/Los_Angeles', 'UTC',
];

export default async function Settings({ searchParams }: { searchParams: Promise<{ ok?: string }> }) {
  const { ok } = await searchParams;
  const { sb, user } = await requireUser();
  if (!user) redirect('/login');
  const s: any = await getSettings(sb, user.id);
  const app = process.env.NEXT_PUBLIC_APP_URL || '';
  const exportUrl = `${app}/api/export/${s.export_token}`;
  const emailOn = !!process.env.RESEND_API_KEY;

  return (
    <Shell>
      <h1>Ajustes</h1>
      <p className="sub">Ajustes de tu cuenta: se aplican a todos tus vídeos.</p>
      {ok && <p className="ok">Guardado.</p>}

      <form action={saveSettings} style={{ maxWidth: 720 }}>
        <div className="card">
          <h2>General</h2>
          <div className="field">
            <label>Zona horaria <span className="hint">(estadísticas por día, &quot;Hoy&quot; y webinars)</span></label>
            <input type="text" name="timezone" list="zones" defaultValue={s.timezone || 'Europe/Madrid'} />
            <datalist id="zones">{ZONES.map((z) => <option key={z} value={z} />)}</datalist>
          </div>
        </div>

        <div className="card">
          <h2>Meta (Pixel y API de Conversiones)</h2>
          <div className="field"><label>ID del Pixel / conjunto de datos</label><input type="text" name="meta_pixel_id" defaultValue={s.meta_pixel_id || ''} /></div>
          <div className="field"><label>Token de la API de Conversiones</label><input type="password" name="meta_capi_token" defaultValue={s.meta_capi_token || ''} /></div>
          <div className="field">
            <label>Código de evento de prueba <span className="hint">(opcional, bórralo después de comprobar)</span></label>
            <input type="text" name="meta_test_event_code" defaultValue={s.meta_test_event_code || ''} />
          </div>
          <p className="hint">Eventos: VSL_25, VSL_50, VSL_75, VSL_95 (% visto con sonido) y VSL_Pitch. Cada vídeo decide si los envía.</p>
        </div>

        <div className="card">
          <h2>Avisos</h2>
          <div className="field">
            <label>Email para avisos</label>
            <input type="text" name="notify_email" defaultValue={s.notify_email || ''} placeholder="tu@email.com" />
            {!emailOn && <p className="hint">Para que lleguen emails falta configurar RESEND_API_KEY en Vercel (ver README).</p>}
          </div>
          <div className="field">
            <label>Webhook general <span className="hint">(Make, Zapier, n8n, Slack…)</span></label>
            <input type="text" name="webhook_url" defaultValue={s.webhook_url || ''} placeholder="https://hook.make.com/..." />
          </div>
          <p className="hint">Qué avisos se envían lo eliges en cada vídeo.</p>
        </div>

        <div className="card">
          <h2>GetResponse</h2>
          <p className="hint">Los leads del formulario dentro del vídeo se añaden a esta lista.</p>
          <div className="field"><label>API key</label><input type="password" name="getresponse_key" defaultValue={s.getresponse_key || ''} /></div>
          <div className="field"><label>ID de la lista (campaignId)</label><input type="text" name="getresponse_campaign" defaultValue={s.getresponse_campaign || ''} /></div>
        </div>

        <button className="btn accent" style={{ marginBottom: 18 }}>Guardar ajustes</button>
      </form>

      <div className="card" style={{ maxWidth: 720 }}>
        <h2>Looker Studio / Google Sheets</h2>
        <p className="hint">Datos diarios por vídeo (cargas, reproducciones, visionado, pitch, conversiones, ingresos, leads) de los últimos 90 días.</p>
        <label>En una celda de Google Sheets pega:</label>
        <CopyBox text={`=IMPORTDATA("${exportUrl}")`} />
        <p className="hint" style={{ marginTop: 10 }}>
          Luego en Looker Studio: Añadir datos → Hojas de cálculo de Google → esa hoja. Este enlace da acceso a tus datos: no lo compartas.
        </p>
        <form action={regenerateExportToken}>
          <button className="btn ghost">Generar enlace nuevo (invalida el anterior)</button>
        </form>
      </div>
    </Shell>
  );
}
