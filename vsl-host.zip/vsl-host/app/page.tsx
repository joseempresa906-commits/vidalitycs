import Link from 'next/link';
import { redirect } from 'next/navigation';
import Shell from '@/components/Shell';
import Uploader from '@/components/Uploader';
import { requireUser } from '@/lib/supabase';
import { thumbUrl, playbackId } from '@/lib/cloudflare';
import { mmss } from '@/lib/stats';

export const dynamic = 'force-dynamic';

export default async function Home() {
  const { sb, user } = await requireUser();
  if (!user) redirect('/login');
  const { data: videos } = await sb.from('videos').select('*').order('created_at', { ascending: false });
  const thumbs = await Promise.all(
    (videos || []).map(async (v) => (v.status === 'ready' ? thumbUrl(await playbackId(v.stream_uid, !!v.protected, 3600), v.thumbnail_time) : null))
  );

  return (
    <Shell>
      <div className="row between" style={{ marginBottom: 22 }}>
        <div>
          <h1>Vídeos</h1>
          <p className="sub" style={{ margin: 0 }}>{videos?.length || 0} vídeos</p>
        </div>
        <Uploader />
      </div>
      {!videos?.length ? (
        <div className="card">Sube tu primer VSL para empezar.</div>
      ) : (
        <div className="vlist">
          {videos.map((v, i) => (
            <Link key={v.id} href={`/videos/${v.id}`} className="vcard">
              <div className="th" style={{ backgroundImage: thumbs[i] ? `url(${thumbs[i]})` : undefined }} />
              <div className="meta">
                <b>{v.name}</b>
                <div className="row" style={{ marginTop: 6 }}>
                  {v.status === 'ready' ? <span className="pill ok">Listo</span> : <span className="pill warn">Procesando</span>}
                  {v.duration ? <span className="hint">{mmss(Number(v.duration))}</span> : null}
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </Shell>
  );
}
