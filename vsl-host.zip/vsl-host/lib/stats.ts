import { dayKey, startOfToday } from '@/lib/tz';

export const VIEW_COLS =
  'played,started,max_second,duration,reached_cta,variant,utm_source,utm_campaign,utm_content,device,converted,conversion_value,conversion_second,funnel,lead,answers,created_at';

export type ViewRow = {
  played: boolean;
  started: boolean;
  max_second: number;
  duration: number | null;
  reached_cta: boolean;
  variant: string | null;
  utm_source: string | null;
  utm_campaign: string | null;
  utm_content: string | null;
  device: string | null;
  converted: boolean;
  conversion_value: number | null;
  conversion_second: number | null;
  funnel: string | null;
  lead: boolean;
  answers: { q: string; a: string; t: number }[] | null;
  created_at: string;
};

export type Summary = {
  loads: number;
  plays: number;
  playRate: number;
  avgPct: number;
  avgSec: number;
  pitch: number;
  pitchRate: number;
  conv: number;
  convRate: number;
  revenue: number;
  leads: number;
};

export function summarize(rows: ViewRow[], duration: number | null): Summary {
  const loads = rows.length;
  const played = rows.filter((r) => r.played);
  const plays = played.length;
  const d = (r: ViewRow) => Number(r.duration || duration || 0);
  const avgPct = plays
    ? played.reduce((a, r) => a + (d(r) ? Math.min(1, Number(r.max_second) / d(r)) : 0), 0) / plays
    : 0;
  const avgSec = plays ? played.reduce((a, r) => a + Number(r.max_second), 0) / plays : 0;
  const pitch = played.filter((r) => r.reached_cta).length;
  const convRows = rows.filter((r) => r.converted);
  const conv = convRows.length;
  return {
    loads,
    plays,
    playRate: loads ? plays / loads : 0,
    avgPct,
    avgSec,
    pitch,
    pitchRate: plays ? pitch / plays : 0,
    conv,
    convRate: plays ? conv / plays : 0,
    revenue: convRows.reduce((a, r) => a + (Number(r.conversion_value) || 0), 0),
    leads: rows.filter((r) => r.lead).length,
  };
}

export function groupBy(rows: ViewRow[], key: (r: ViewRow) => string, duration: number | null) {
  const map = new Map<string, ViewRow[]>();
  rows.forEach((r) => {
    const k = key(r);
    map.set(k, [...(map.get(k) || []), r]);
  });
  return [...map.entries()]
    .map(([k, rs]) => ({ key: k, ...summarize(rs, duration) }))
    .sort((a, b) => b.plays - a.plays);
}

/** Curva de retención: % de reproducciones que siguen viendo en cada punto. */
export function retention(rows: ViewRow[], duration: number | null, points = 120) {
  const played = rows.filter((r) => r.played).map((r) => Number(r.max_second));
  const d = Number(duration || 0);
  if (!d || !played.length) return [] as { s: number; pct: number }[];
  played.sort((a, b) => a - b);
  const n = played.length;
  const out: { s: number; pct: number }[] = [];
  let i = 0;
  for (let p = 0; p <= points; p++) {
    const s = (d * p) / points;
    while (i < n && played[i] < s) i++;
    out.push({ s, pct: ((n - i) / n) * 100 });
  }
  return out;
}

/** Ventas por momento del vídeo (mismos puntos que la curva). */
export function conversionBars(rows: ViewRow[], duration: number | null, points = 120) {
  const d = Number(duration || 0);
  const bars = new Array(points + 1).fill(0);
  if (!d) return bars;
  rows.forEach((r) => {
    if (!r.converted || r.conversion_second == null) return;
    const i = Math.min(points, Math.max(0, Math.round((Number(r.conversion_second) / d) * points)));
    bars[i]++;
  });
  return bars;
}

/** Reproducciones y conversiones por día en la zona horaria del usuario. */
export function daily(rows: ViewRow[], tz: string) {
  const map = new Map<string, { plays: number; conv: number }>();
  rows.forEach((r) => {
    const k = dayKey(r.created_at, tz);
    const a = map.get(k) || { plays: 0, conv: 0 };
    if (r.played) a.plays++;
    if (r.converted) a.conv++;
    map.set(k, a);
  });
  return [...map.entries()].sort(([a], [b]) => (a < b ? -1 : 1)).map(([day, v]) => ({ day, ...v }));
}

/** Respuestas a las preguntas interactivas. */
export function answerStats(rows: ViewRow[]) {
  const map = new Map<string, Map<string, number>>();
  rows.forEach((r) =>
    (r.answers || []).forEach((x) => {
      const q = map.get(x.q) || new Map<string, number>();
      q.set(x.a, (q.get(x.a) || 0) + 1);
      map.set(x.q, q);
    })
  );
  return [...map.entries()].map(([q, m]) => {
    const total = [...m.values()].reduce((a, b) => a + b, 0);
    return { q, total, options: [...m.entries()].map(([a, n]) => ({ a, n, pct: total ? n / total : 0 })).sort((x, y) => y.n - x.n) };
  });
}

/** Test de dos proporciones: devuelve la confianza (0-1) de que A y B son distintos. */
export function confidence(x1: number, n1: number, x2: number, n2: number) {
  if (n1 < 1 || n2 < 1) return 0;
  const p1 = x1 / n1, p2 = x2 / n2, p = (x1 + x2) / (n1 + n2);
  const se = Math.sqrt(p * (1 - p) * (1 / n1 + 1 / n2));
  if (!se) return 0;
  const z = Math.abs(p1 - p2) / se;
  return erf(z / Math.SQRT2);
}
function erf(x: number) {
  const t = 1 / (1 + 0.3275911 * x);
  return 1 - ((((1.061405429 * t - 1.453152027) * t + 1.421413741) * t - 0.284496736) * t + 0.254829592) * t * Math.exp(-x * x);
}

export const pct = (n: number) => `${(n * 100).toFixed(1)}%`;
export const money = (n: number) => n.toLocaleString('es-ES', { maximumFractionDigits: 2 });
export function mmss(s: number) {
  s = Math.round(s);
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = s % 60;
  return h ? `${h}:${String(m).padStart(2, '0')}:${String(x).padStart(2, '0')}` : `${m}:${String(x).padStart(2, '0')}`;
}

export function rangeFrom(d: string | undefined, tz: string) {
  if (d === '1') return startOfToday(tz).toISOString();
  const days = d === 'all' ? 3650 : Number(d) || 30;
  return new Date(Date.now() - days * 86400000).toISOString();
}

/** Lee todas las filas paginando (Supabase devuelve 1000 por petición). */
export async function fetchAll<T>(q: (from: number, to: number) => PromiseLike<{ data: T[] | null }>, max = 100000) {
  const out: T[] = [];
  for (let from = 0; from < max; from += 1000) {
    const { data } = await q(from, from + 999);
    if (!data?.length) break;
    out.push(...data);
    if (data.length < 1000) break;
  }
  return out;
}
