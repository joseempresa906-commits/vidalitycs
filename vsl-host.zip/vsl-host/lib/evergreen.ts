import { localParts, zonedToUtc, safeTz } from '@/lib/tz';

export type EvergreenCfg = {
  tz?: string;
  times?: string[];       // ["19:00", "21:30"]
  days?: number[];        // 0=domingo … 6=sábado (vacío = todos)
  every_minutes?: number; // alternativa: cada X minutos (p. ej. 15)
};

/**
 * Calcula la sesión en curso (si la hay) y la siguiente.
 * Devuelve instantes en ms UTC para que el navegador solo tenga que restar.
 */
export function evergreenSessions(cfg: EvergreenCfg, durationSec: number, now = Date.now()) {
  const tz = safeTz(cfg.tz);
  const dur = Math.max(1, durationSec) * 1000;
  const starts: number[] = [];

  if (cfg.every_minutes && cfg.every_minutes > 0) {
    const step = cfg.every_minutes * 60000;
    const today = localParts(tz, new Date(now));
    const midnight = zonedToUtc(today.y, today.m, today.d, 0, 0, tz).getTime();
    const k = Math.floor((now - midnight) / step);
    for (let i = k - Math.ceil(dur / step) - 1; i <= k + 2; i++) starts.push(midnight + i * step);
  } else {
    const times = (cfg.times || []).filter((t) => /^\d{1,2}:\d{2}$/.test(t));
    const days = cfg.days && cfg.days.length ? cfg.days : [0, 1, 2, 3, 4, 5, 6];
    for (let off = -1; off <= 8; off++) {
      const p = localParts(tz, new Date(now + off * 86400000));
      if (!days.includes(p.wd)) continue;
      for (const t of times) {
        const [hh, mm] = t.split(':').map(Number);
        starts.push(zonedToUtc(p.y, p.m, p.d, hh, mm, tz).getTime());
      }
    }
  }
  starts.sort((a, b) => a - b);
  const current = [...starts].reverse().find((s) => s <= now && now < s + dur) ?? null;
  const next = starts.find((s) => s > now) ?? null;
  return { current, next, now };
}
