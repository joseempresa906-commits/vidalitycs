import crypto from 'crypto';
import { supabaseAdmin } from '@/lib/supabase';

const API = 'https://api.cloudflare.com/client/v4';

function headers() {
  return { Authorization: `Bearer ${process.env.CLOUDFLARE_STREAM_TOKEN}` };
}

export function streamBase() {
  return `${API}/accounts/${process.env.CLOUDFLARE_ACCOUNT_ID}/stream`;
}
const CDN = () => `https://${process.env.NEXT_PUBLIC_CF_STREAM_CUSTOMER}.cloudflarestream.com`;

/** Inicia una subida tus "direct creator" y devuelve la URL de subida y el uid del vídeo. */
export async function createTusUpload(uploadLength: string, uploadMetadata: string) {
  const res = await fetch(`${streamBase()}?direct_user=true`, {
    method: 'POST',
    headers: {
      ...headers(),
      'Tus-Resumable': '1.0.0',
      'Upload-Length': uploadLength,
      'Upload-Metadata': uploadMetadata,
    },
  });
  if (!res.ok) throw new Error(`Cloudflare ${res.status}: ${await res.text()}`);
  return {
    location: res.headers.get('location')!,
    uid: res.headers.get('stream-media-id')!,
  };
}

export async function getStreamVideo(uid: string) {
  const res = await fetch(`${streamBase()}/${uid}`, { headers: headers(), cache: 'no-store' });
  if (!res.ok) return null;
  const json = await res.json();
  return json.result as {
    uid: string;
    readyToStream: boolean;
    duration: number;
    status: { state: string };
    input: { width: number; height: number };
  };
}

export async function deleteStreamVideo(uid: string) {
  await fetch(`${streamBase()}/${uid}`, { method: 'DELETE', headers: headers() });
}

/** Activa/desactiva URLs firmadas y dominios permitidos en Cloudflare. */
export async function setStreamProtection(uid: string, on: boolean, domains: string[]) {
  const res = await fetch(`${streamBase()}/${uid}`, {
    method: 'POST',
    headers: { ...headers(), 'Content-Type': 'application/json' },
    body: JSON.stringify({ uid, requireSignedURLs: on, allowedOrigins: on ? domains : [] }),
  });
  if (!res.ok) throw new Error(`Cloudflare ${res.status}: ${await res.text()}`);
}

// ---------- Firma de URLs (protección contra descargas y enlaces robados) ----------
type SigningKey = { id: string; pem: string };
let cachedKey: SigningKey | null = null;

/** Devuelve la clave de firma; la crea en Cloudflare la primera vez y la guarda en la base de datos. */
export async function getSigningKey(create = false): Promise<SigningKey | null> {
  if (cachedKey) return cachedKey;
  const sb = supabaseAdmin();
  const { data } = await sb.from('app_secrets').select('value').eq('key', 'cf_signing_key').maybeSingle();
  if (data?.value) return (cachedKey = JSON.parse(data.value));
  if (!create) return null;
  const res = await fetch(`${streamBase()}/keys`, { method: 'POST', headers: headers() });
  if (!res.ok) throw new Error(`Cloudflare ${res.status}: ${await res.text()}`);
  const r = (await res.json()).result;
  const key = { id: r.id, pem: Buffer.from(r.pem, 'base64').toString('utf8') };
  await sb.from('app_secrets').upsert({ key: 'cf_signing_key', value: JSON.stringify(key) });
  return (cachedKey = key);
}

const b64url = (b: Buffer | string) => Buffer.from(b).toString('base64url');

export async function signedToken(uid: string, ttlSeconds: number) {
  const key = await getSigningKey();
  if (!key) return null;
  const header = { alg: 'RS256', kid: key.id };
  const payload = { sub: uid, kid: key.id, exp: Math.floor(Date.now() / 1000) + ttlSeconds, downloadable: false };
  const data = `${b64url(JSON.stringify(header))}.${b64url(JSON.stringify(payload))}`;
  const sig = crypto.createSign('RSA-SHA256').update(data).sign(key.pem);
  return `${data}.${b64url(sig)}`;
}

/** id de ruta: el uid normal, o un token firmado si el vídeo está protegido. */
export async function playbackId(uid: string, isProtected: boolean, ttlSeconds = 6 * 3600) {
  if (!isProtected) return uid;
  return (await signedToken(uid, ttlSeconds)) || uid;
}

export function hlsUrl(id: string) {
  return `${CDN()}/${id}/manifest/video.m3u8`;
}

export function thumbUrl(id: string, time = 1) {
  return `${CDN()}/${id}/thumbnails/thumbnail.jpg?time=${time}s&height=720`;
}

export function gifUrl(id: string, start: number, duration: number, height: number) {
  return `${CDN()}/${id}/thumbnails/thumbnail.gif?time=${start}s&duration=${duration}s&height=${height}&fps=12`;
}
