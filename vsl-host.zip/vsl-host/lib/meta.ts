import crypto from 'crypto';

/**
 * Envía un evento a la API de Conversiones de Meta.
 * Usa el mismo event_id que el navegador para que Meta los deduplique.
 */
export async function sendCapiEvent(opts: {
  pixelId: string;
  token: string;
  testCode?: string | null;
  eventName: string;
  eventId: string;
  url?: string | null;
  ip?: string | null;
  ua?: string | null;
  fbp?: string | null;
  fbc?: string | null;
  externalId?: string | null;
  custom?: Record<string, unknown>;
}) {
  const user_data: Record<string, unknown> = {};
  if (opts.ip) user_data.client_ip_address = opts.ip;
  if (opts.ua) user_data.client_user_agent = opts.ua;
  if (opts.fbp) user_data.fbp = opts.fbp;
  if (opts.fbc) user_data.fbc = opts.fbc;
  if (opts.externalId)
    user_data.external_id = crypto.createHash('sha256').update(opts.externalId).digest('hex');

  const body: Record<string, unknown> = {
    data: [
      {
        event_name: opts.eventName,
        event_time: Math.floor(Date.now() / 1000),
        event_id: opts.eventId,
        action_source: 'website',
        event_source_url: opts.url || undefined,
        user_data,
        custom_data: opts.custom || {},
      },
    ],
  };
  if (opts.testCode) body.test_event_code = opts.testCode;

  try {
    await fetch(`https://graph.facebook.com/v21.0/${opts.pixelId}/events?access_token=${opts.token}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
  } catch {
    /* no bloquear el tracking si Meta falla */
  }
}
