/** Utilidades de zona horaria sin dependencias. */

/** Diferencia (ms) entre la hora local de `tz` y UTC en un instante dado. */
export function tzOffsetMs(tz: string, at: Date = new Date()) {
  const f = new Intl.DateTimeFormat('en-US', {
    timeZone: tz, hourCycle: 'h23', year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit',
  });
  const p = Object.fromEntries(f.formatToParts(at).map((x) => [x.type, x.value]));
  const asUtc = Date.UTC(+p.year, +p.month - 1, +p.day, +p.hour, +p.minute, +p.second);
  return asUtc - Math.floor(at.getTime() / 1000) * 1000;
}

/** Instante UTC correspondiente a una fecha/hora local en `tz`. */
export function zonedToUtc(y: number, m: number, d: number, hh: number, mm: number, tz: string) {
  const guess = Date.UTC(y, m - 1, d, hh, mm);
  const off = tzOffsetMs(tz, new Date(guess));
  const t = guess - off;
  const off2 = tzOffsetMs(tz, new Date(t)); // ajuste en cambios de horario
  return new Date(guess - off2);
}

/** Fecha local (y, m, d, día de la semana) en `tz`. */
export function localParts(tz: string, at: Date = new Date()) {
  const f = new Intl.DateTimeFormat('en-US', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit', weekday: 'short' });
  const p = Object.fromEntries(f.formatToParts(at).map((x) => [x.type, x.value]));
  const wd = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].indexOf(p.weekday);
  return { y: +p.year, m: +p.month, d: +p.day, wd };
}

export function startOfToday(tz: string) {
  const { y, m, d } = localParts(tz);
  return zonedToUtc(y, m, d, 0, 0, tz);
}

/** 'YYYY-MM-DD' en la zona horaria dada. */
export function dayKey(iso: string | Date, tz: string) {
  return new Intl.DateTimeFormat('en-CA', { timeZone: tz }).format(new Date(iso));
}

export function safeTz(tz?: string | null) {
  try {
    if (tz) { new Intl.DateTimeFormat('en-US', { timeZone: tz }); return tz; }
  } catch {}
  return 'Europe/Madrid';
}
