/** Avisos: webhook (Zapier, Make, n8n, Slack…), email (Resend) y alta en GetResponse. */

type Settings = Record<string, any> | null;

const LABELS: Record<string, string> = {
  play: 'Alguien ha empezado a ver tu vídeo',
  pitch: 'Alguien ha llegado al pitch',
  lead: 'Nuevo lead desde el vídeo',
  conversion: 'Nueva conversión desde el vídeo',
};

async function withTimeout(p: Promise<unknown>, ms = 4000) {
  await Promise.race([p.catch(() => {}), new Promise((r) => setTimeout(r, ms))]);
}

export async function notify(
  event: 'play' | 'pitch' | 'lead' | 'conversion',
  video: Record<string, any>,
  settings: Settings,
  payload: Record<string, unknown>
) {
  const on = (video.notify || {})[event];
  if (!on) return;
  const body = { event, title: LABELS[event], video_id: video.id, video_name: video.name, at: new Date().toISOString(), ...payload };
  const jobs: Promise<unknown>[] = [];

  const hook = video.webhook_url || settings?.webhook_url;
  if (hook) {
    jobs.push(fetch(hook, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }));
  }

  const to = settings?.notify_email;
  if (to && process.env.RESEND_API_KEY) {
    const rows = Object.entries(payload)
      .filter(([, v]) => v !== null && v !== undefined && v !== '')
      .map(([k, v]) => `<tr><td style="color:#888;padding:2px 10px 2px 0">${k}</td><td>${escapeHtml(typeof v === 'object' ? JSON.stringify(v) : String(v))}</td></tr>`)
      .join('');
    jobs.push(
      fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: { Authorization: `Bearer ${process.env.RESEND_API_KEY}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          from: process.env.NOTIFY_FROM || 'VSL Host <onboarding@resend.dev>',
          to: [to],
          subject: `${LABELS[event]} · ${video.name}`,
          html: `<div style="font-family:sans-serif"><h2 style="margin:0 0 10px">${LABELS[event]}</h2><p><b>${escapeHtml(video.name)}</b></p><table>${rows}</table></div>`,
        }),
      })
    );
  }
  await withTimeout(Promise.all(jobs));
}

export async function addToGetResponse(settings: Settings, lead: { email?: string | null; name?: string | null }) {
  if (!settings?.getresponse_key || !settings?.getresponse_campaign || !lead.email) return;
  await withTimeout(
    fetch('https://api.getresponse.com/v3/contacts', {
      method: 'POST',
      headers: { 'X-Auth-Token': `api-key ${settings.getresponse_key}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: lead.email,
        name: lead.name || undefined,
        campaign: { campaignId: settings.getresponse_campaign },
      }),
    })
  );
}

function escapeHtml(s: string) {
  return s.replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]!));
}
