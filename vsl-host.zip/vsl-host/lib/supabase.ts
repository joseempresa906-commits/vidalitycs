import { createServerClient } from '@supabase/ssr';
import { createClient } from '@supabase/supabase-js';
import { cookies } from 'next/headers';

/** Cliente con la sesión del usuario logueado (respeta RLS). */
export async function supabaseServer() {
  const store = await cookies();
  return createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll: () => store.getAll(),
        setAll: (list) => {
          try {
            list.forEach(({ name, value, options }) => store.set(name, value, options));
          } catch {
            /* llamado desde un Server Component: lo refresca el middleware */
          }
        },
      },
    }
  );
}

/** Cliente con service role: solo en servidor, para endpoints públicos (player / tracking). */
export function supabaseAdmin() {
  return createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, {
    auth: { persistSession: false },
  });
}

export async function requireUser() {
  const sb = await supabaseServer();
  const { data } = await sb.auth.getUser();
  return { sb, user: data.user };
}

/** Ajustes del usuario; crea la fila la primera vez (así existe el token de exportación). */
export async function getSettings(sb: Awaited<ReturnType<typeof supabaseServer>>, userId: string) {
  const { data } = await sb.from('settings').select('*').eq('owner_id', userId).maybeSingle();
  if (data) return data;
  const { data: created } = await sb.from('settings').insert({ owner_id: userId }).select('*').single();
  return created || { owner_id: userId, timezone: 'Europe/Madrid' };
}
