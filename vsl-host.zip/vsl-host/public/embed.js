/*!
 * VSL Host — player embebible v2
 * Uso:
 *   <div data-vsl="ID_DEL_VIDEO_O_TEST"></div>
 *   <script async src="https://TU-APP/embed.js"></script>
 * Elementos que aparecen en el momento del pitch:
 *   <div class="vsl-reveal">...</div>            (segundo configurado en el panel)
 *   <div data-vsl-reveal="125">...</div>          (segundo propio)
 * Enlaces que deben llevar el id de sesión (para atribuir la venta): data-vsl-link, o cualquier
 * enlace dentro de un bloque vsl-reveal.
 */
(function () {
  var script = document.currentScript;
  var BASE = script ? new URL(script.src).origin : '';
  if (window.__vslh) { window.__vslh.scan(); return; }

  var HLS_CDN = 'https://cdn.jsdelivr.net/npm/hls.js@1.5.17/dist/hls.min.js';
  var THRESHOLDS = [25, 50, 75, 95];
  var RATIOS = { '16:9': 56.25, '9:16': 177.78, '1:1': 100, '4:5': 125 };
  var MOBILE = /Mobi|Android|iPhone|iPad/i.test(navigator.userAgent);

  // ---------- estilos ----------
  var css =
    '.vsl-reveal:not(.vslh-on),[data-vsl-reveal]:not(.vslh-on){display:none!important}' +
    '.vslh{position:relative;width:100%;background:#000;overflow:hidden;border-radius:8px;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;-webkit-tap-highlight-color:transparent;user-select:none;-webkit-user-select:none}' +
    '.vslh:fullscreen{padding-top:0!important;border-radius:0}.vslh:-webkit-full-screen{padding-top:0!important;border-radius:0}' +
    '.vslh:fullscreen video{object-fit:contain}' +
    '.vslh video{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;background:#000}' +
    '.vslh-layer{position:absolute;inset:0;display:none;align-items:center;justify-content:center;cursor:pointer;z-index:3}' +
    '.vslh-layer.on{display:flex}' +
    '.vslh-unmute{display:flex;align-items:center;flex-direction:column;gap:10px;padding:22px 26px;border-radius:14px;color:#fff;text-align:center;box-shadow:0 10px 30px rgba(0,0,0,.35);max-width:80%;animation:vslhPulse 1.6s ease-in-out infinite}' +
    '.vslh-unmute b{font-size:clamp(15px,3.2vw,22px);line-height:1.2}' +
    '.vslh-unmute span{font-size:clamp(13px,2.6vw,17px);opacity:.95}' +
    '.vslh-unmute svg{width:clamp(34px,7vw,54px);height:auto}' +
    '@keyframes vslhPulse{0%,100%{transform:scale(1)}50%{transform:scale(1.04)}}' +
    '@keyframes vslhShake{0%,86%,100%{transform:translateX(0)}88%,92%,96%{transform:translateX(-5px)}90%,94%,98%{transform:translateX(5px)}}' +
    '.vslh-play{width:clamp(64px,13vw,96px);height:clamp(64px,13vw,96px);border-radius:50%;display:flex;align-items:center;justify-content:center;box-shadow:0 10px 30px rgba(0,0,0,.35)}' +
    '.vslh-play svg{width:42%;margin-left:6%}' +
    '.vslh-dim{background:rgba(0,0,0,.35)}' +
    '.vslh-bar{position:absolute;left:0;right:0;bottom:0;background:rgba(255,255,255,.18);z-index:2;display:none}' +
    '.vslh-bar.on{display:block}' +
    '.vslh-bar i{display:block;height:100%;width:0;transition:width .25s linear}' +
    '.vslh-panel{flex-direction:column;gap:12px;background:rgba(0,0,0,.82);color:#fff;text-align:center;padding:18px;cursor:default;overflow:auto}' +
    '.vslh-panel p{margin:0;font-size:clamp(15px,3vw,21px);font-weight:700;line-height:1.25}' +
    '.vslh-panel small{font-size:clamp(12px,2.4vw,15px);opacity:.85}' +
    '.vslh-panel .row{display:flex;gap:10px;flex-wrap:wrap;justify-content:center}' +
    '.vslh-panel button{border:0;border-radius:8px;padding:12px 18px;font-size:15px;font-weight:700;cursor:pointer;font-family:inherit}' +
    '.vslh-panel form{display:flex;flex-direction:column;gap:8px;width:min(340px,92%)}' +
    '.vslh-panel input,.vslh-panel select{border:0;border-radius:8px;padding:11px 12px;font-size:15px;font-family:inherit;width:100%;box-sizing:border-box}' +
    '.vslh-panel .err{color:#fca5a5;font-size:13px;min-height:16px}' +
    '.vslh-panel .skip{background:none;color:#ddd;font-weight:500;text-decoration:underline;padding:4px}' +
    '.vslh-opts{display:flex;flex-direction:column;gap:8px;width:min(420px,92%)}' +
    '.vslh-opts button{width:100%}' +
    '.vslh-spinwrap{flex-direction:column;gap:8px;color:#fff;font-size:13px;cursor:default}' +
    '.vslh-spin{width:44px;height:44px;border:4px solid rgba(255,255,255,.25);border-top-color:#fff;border-radius:50%;animation:vslhSpin .8s linear infinite}' +
    '@keyframes vslhSpin{to{transform:rotate(360deg)}}' +
    '.vslh-fs{position:absolute;right:10px;bottom:14px;z-index:4;width:34px;height:34px;border-radius:6px;background:rgba(0,0,0,.45);display:none;align-items:center;justify-content:center;cursor:pointer}' +
    '.vslh-fs.on{display:flex}.vslh-fs svg{width:20px}' +
    '.vslh-live{position:absolute;left:10px;top:10px;z-index:4;background:#dc2626;color:#fff;font-size:12px;font-weight:800;letter-spacing:.04em;padding:4px 9px;border-radius:5px;display:none}' +
    '.vslh-live.on{display:block}' +
    '.vslh-clock{font-size:clamp(28px,7vw,52px);font-weight:800;font-variant-numeric:tabular-nums;letter-spacing:.02em}' +
    '.vslh-cta{display:none;margin:16px auto 0;text-align:center}' +
    '.vslh-cta.on{display:block;animation:vslhIn .5s ease-out}' +
    '.vslh-cta a{display:inline-block;text-decoration:none;font-weight:800;box-shadow:0 8px 24px rgba(0,0,0,.2);box-sizing:border-box}' +
    '@keyframes vslhIn{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}';
  var st = document.createElement('style');
  st.textContent = css;
  (document.head || document.documentElement).appendChild(st);

  var ICON_SOUND = '<svg viewBox="0 0 24 24" fill="#fff"><path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3A4.5 4.5 0 0 0 14 8v8a4.5 4.5 0 0 0 2.5-4zM14 3.2v2.1a7 7 0 0 1 0 13.4v2.1a9 9 0 0 0 0-17.6z"/></svg>';
  var ICON_PLAY = '<svg viewBox="0 0 24 24" fill="#fff"><path d="M8 5v14l11-7z"/></svg>';
  var ICON_FS = '<svg viewBox="0 0 24 24" fill="#fff"><path d="M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5zm12 7h-3v2h5v-5h-2v3zM14 5v2h3v3h2V5h-5z"/></svg>';

  // ---------- utilidades ----------
  function ls(k, v) {
    try { if (v === undefined) return localStorage.getItem(k); if (v === null) localStorage.removeItem(k); else localStorage.setItem(k, v); } catch (e) { return null; }
  }
  function uid() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 10) + Math.random().toString(36).slice(2, 10); }
  function cookie(n) { var m = document.cookie.match(new RegExp('(?:^|; )' + n + '=([^;]*)')); return m ? decodeURIComponent(m[1]) : null; }
  function utms() {
    var keys = ['utm_source', 'utm_medium', 'utm_campaign', 'utm_content', 'utm_term'];
    var out = {}, q = new URLSearchParams(location.search), stored = {};
    try { stored = JSON.parse(sessionStorage.getItem('vslh_utm') || '{}'); } catch (e) {}
    keys.forEach(function (k) { out[k] = q.get(k) || stored[k] || undefined; });
    try { sessionStorage.setItem('vslh_utm', JSON.stringify(out)); } catch (e) {}
    return out;
  }
  var hlsPromise;
  function loadHls() {
    if (window.Hls) return Promise.resolve(window.Hls);
    if (!hlsPromise) hlsPromise = new Promise(function (res, rej) {
      var s = document.createElement('script'); s.src = HLS_CDN; s.async = true;
      s.onload = function () { res(window.Hls); }; s.onerror = rej; document.head.appendChild(s);
    });
    return hlsPromise;
  }
  function el(tag, cls, html) { var e = document.createElement(tag); if (cls) e.className = cls; if (html) e.innerHTML = html; return e; }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function withSid(url, sid) {
    try { var u = new URL(url, location.href); u.searchParams.set('vsl_sid', sid); return u.toString(); } catch (e) { return url; }
  }
  function clock(ms) {
    var s = Math.max(0, Math.floor(ms / 1000)), h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = s % 60;
    var p = function (n) { return (n < 10 ? '0' : '') + n; };
    return (h ? p(h) + ':' : '') + p(m) + ':' + p(x);
  }
  function post(path, body) {
    var url = BASE + path, data = JSON.stringify(body);
    if (navigator.sendBeacon && navigator.sendBeacon(url, data)) return;
    try { fetch(url, { method: 'POST', body: data, keepalive: true, headers: { 'Content-Type': 'text/plain' } }); } catch (e) {}
  }

  // ---------- revelar elementos de la página ----------
  function revealPage(videoId, t, revealAt, force) {
    var changed = false;
    document.querySelectorAll('.vsl-reveal:not(.vslh-on)').forEach(function (n) {
      if (force || (revealAt != null && t >= revealAt)) { n.classList.add('vslh-on'); changed = true; }
    });
    document.querySelectorAll('[data-vsl-reveal]:not(.vslh-on)').forEach(function (n) {
      var s = parseFloat(n.getAttribute('data-vsl-reveal'));
      if (force || (!isNaN(s) && t >= s)) { n.classList.add('vslh-on'); changed = true; }
    });
    if (changed) {
      ls('vslh_rev_' + videoId, '1');
      window.dispatchEvent(new CustomEvent('vsl:reveal', { detail: { videoId: videoId, second: t } }));
    }
  }

  // Enlaces de la página (pitch / data-vsl-link): llevan la sesión para atribuir la venta
  var active = null; // { sid, onClick }
  document.addEventListener('click', function (e) {
    var a = e.target && e.target.closest ? e.target.closest('a[href]') : null;
    if (!a || !active) return;
    if (a.closest('.vslh-cta')) return; // el botón propio ya lo gestiona
    if (!a.closest('.vsl-reveal,[data-vsl-reveal],[data-vsl-link]') && !a.hasAttribute('data-vsl-link')) return;
    a.href = withSid(a.href, active.sid);
    active.onClick();
  }, true);

  // ---------- player ----------
  function init(root, id, opts) {
    opts = opts || {};
    root.setAttribute('data-vslh-init', '1');
    var preview = root.getAttribute('data-preview') === '1';
    fetch(BASE + '/api/player/' + id)
      .then(function (r) { if (!r.ok) throw new Error(String(r.status)); return r.json(); })
      .then(function (data) {
        var cfg, testId = null, variant = null;
        if (data.type === 'test') {
          testId = data.testId;
          var key = 'vslh_ab_' + testId;
          variant = ls(key);
          if (variant !== 'A' && variant !== 'B') { variant = Math.random() < data.split ? 'A' : 'B'; ls(key, variant); }
          cfg = data.variants[variant];
        } else cfg = data.video;
        build(root, cfg, { testId: testId, variant: variant, preview: preview, startNow: opts.startNow });
      })
      .catch(function () { root.innerHTML = '<div style="padding:20px;color:#999;font:14px sans-serif">Vídeo no disponible</div>'; });
  }

  function build(root, cfg, ctx) {
    var preview = ctx.preview;
    var color = cfg.color || '#E11D48';
    var sid = uid();
    var dur = cfg.duration || 0;
    var state = 'idle'; // idle | preview | playing | paused | gate | question | waiting | ended
    var dead = false;
    var maxT = 0, lastSent = -1, sentTh = {}, ctaFired = false, pending = false;
    var resumeKey = 'vslh_t_' + cfg.id;
    var gateKey = 'vslh_gate_' + cfg.id;
    var gateDone = !cfg.gate || ls(gateKey) === '1';
    var answered = {};
    var evergreen = cfg.mode === 'evergreen' && cfg.live;
    var skew = evergreen ? Date.now() - cfg.live.now : 0;
    var liveStart = evergreen ? cfg.live.current : null;
    var labels = (evergreen && cfg.live.labels) || {};
    var allowPause = cfg.allowPause && !evergreen;
    var autoplayOn = !preview && (cfg.autoplay === 'always' || (cfg.autoplay === 'desktop' && !MOBILE) || (cfg.autoplay === 'mobile' && MOBILE));

    root.innerHTML = '';
    var box = el('div', 'vslh');
    box.style.paddingTop = (RATIOS[cfg.aspect] || 56.25) + '%';
    var v = document.createElement('video');
    v.setAttribute('playsinline', ''); v.setAttribute('webkit-playsinline', '');
    v.preload = 'metadata'; if (cfg.poster) v.poster = cfg.poster; v.muted = true;
    v.disablePictureInPicture = true;
    v.setAttribute('controlslist', 'nodownload noplaybackrate noremoteplayback');
    box.addEventListener('contextmenu', function (e) { e.preventDefault(); });

    // capas
    var lUnmute = el('div', 'vslh-layer');
    var badge = el('div', 'vslh-unmute', ICON_SOUND + '<b></b><span></span>');
    badge.style.background = color;
    badge.querySelector('b').textContent = cfg.unmuteTitle || 'Tu vídeo ya ha comenzado';
    badge.querySelector('span').textContent = cfg.unmuteSubtitle || 'Haz clic para escuchar';
    lUnmute.appendChild(badge);

    var lPlay = el('div', 'vslh-layer vslh-dim');
    var pb = el('div', 'vslh-play', ICON_PLAY); pb.style.background = color; lPlay.appendChild(pb);

    var lLoad = el('div', 'vslh-layer vslh-spinwrap', '<div class="vslh-spin"></div><span class="vslh-pct"></span>');
    var pctEl = lLoad.querySelector('.vslh-pct');
    var lPanel = el('div', 'vslh-layer vslh-panel'); // resume, gate, preguntas, directo
    var bar = el('div', 'vslh-bar'); var fill = el('i'); fill.style.background = color; bar.appendChild(fill);
    bar.style.height = (cfg.barHeight || 6) + 'px';
    var fsBtn = el('div', 'vslh-fs', ICON_FS);
    var liveBadge = el('div', 'vslh-live', '● ' + esc(labels.live || 'EN DIRECTO'));

    [v, bar, lUnmute, lPlay, lLoad, lPanel, fsBtn, liveBadge].forEach(function (n) { box.appendChild(n); });
    root.appendChild(box);

    // botón CTA bajo el vídeo
    var ctaBox = null, ctaA = null;
    if (cfg.cta) {
      var s = cfg.cta.style || {};
      var sizes = { s: ['14px', '10px 18px'], m: ['clamp(16px,3.4vw,20px)', '16px 28px'], l: ['clamp(18px,4.2vw,26px)', '20px 38px'] };
      var sz = sizes[s.size] || sizes.m;
      ctaBox = el('div', 'vslh-cta');
      ctaA = el('a'); ctaA.href = cfg.cta.url; ctaA.textContent = cfg.cta.text;
      ctaA.style.background = s.bg || color; ctaA.style.color = s.fg || '#fff';
      ctaA.style.fontSize = sz[0]; ctaA.style.padding = sz[1];
      ctaA.style.borderRadius = s.shape === 'square' ? '0' : s.shape === 'pill' ? '999px' : '10px';
      if (s.full) { ctaA.style.display = 'block'; ctaA.style.width = '100%'; }
      if (s.anim === 'pulse') ctaA.style.animation = 'vslhPulse 1.4s ease-in-out infinite';
      if (s.anim === 'shake') ctaA.style.animation = 'vslhShake 3s ease-in-out infinite';
      ctaA.addEventListener('click', function () { ctaA.href = withSid(cfg.cta.url, sid); clicked(); });
      ctaBox.appendChild(ctaA); root.appendChild(ctaBox);
    }

    if (ls('vslh_rev_' + cfg.id) === '1') {
      revealPage(cfg.id, 0, null, true);
      if (ctaBox) ctaBox.classList.add('on');
    }

    function show(layer) {
      [lUnmute, lPlay, lLoad, lPanel].forEach(function (l) { l.classList.toggle('on', l === layer); });
      fsBtn.classList.toggle('on', !!cfg.fullscreen && (state === 'playing' || state === 'paused') && !layer);
      liveBadge.classList.toggle('on', !!evergreen && state === 'playing');
    }
    function panel(html) { lPanel.innerHTML = html; show(lPanel); return lPanel; }

    // ----- tracking -----
    var u = utms();
    function send(ev, extra) {
      if (preview || dead) return;
      var body = {
        sid: sid, vid: cfg.id, tid: ctx.testId, variant: ctx.variant, ev: ev,
        t: Math.round(maxT * 10) / 10, dur: dur || null,
        utm: u, ref: document.referrer, url: location.href.split('#')[0],
        dev: MOBILE ? 'mobile' : 'desktop', fbp: cookie('_fbp'), fbc: cookie('_fbc')
      };
      if (extra) for (var k in extra) body[k] = extra[k];
      post('/api/track', body);
    }
    function fbq(name, eventId) {
      if (preview || !cfg.metaEvents || typeof window.fbq !== 'function') return;
      try { window.fbq('trackCustom', name, { video_id: cfg.id }, { eventID: eventId }); } catch (e) {}
    }
    function clicked() { send('click', { ct: Math.round(v.currentTime * 10) / 10 }); }

    send('load');

    // ----- carga del vídeo -----
    var hls = null;
    var ready = new Promise(function (res) {
      if (v.canPlayType('application/vnd.apple.mpegurl')) { v.src = cfg.hls; res(); return; }
      loadHls().then(function (Hls) {
        if (Hls.isSupported()) {
          hls = new Hls({ capLevelToPlayerSize: true, startLevel: -1, maxBufferLength: 20 });
          hls.loadSource(cfg.hls); hls.attachMedia(v);
        } else v.src = cfg.hls;
        res();
      }).catch(function () { v.src = cfg.hls; res(); });
    });

    v.addEventListener('loadedmetadata', function () { if (v.duration && isFinite(v.duration)) dur = v.duration; });
    function bufferPct() {
      try {
        for (var i = 0; i < v.buffered.length; i++) {
          if (v.buffered.start(i) <= v.currentTime + 0.1 && v.buffered.end(i) >= v.currentTime) {
            return Math.min(99, Math.round(((v.buffered.end(i) - v.currentTime) / 4) * 100));
          }
        }
      } catch (e) {}
      return 0;
    }
    function loading() { if (state === 'playing') { pctEl.textContent = 'Cargando… ' + bufferPct() + '%'; show(lLoad); } }
    v.addEventListener('waiting', loading);
    v.addEventListener('progress', function () { if (lLoad.classList.contains('on')) pctEl.textContent = 'Cargando… ' + bufferPct() + '%'; });
    v.addEventListener('playing', function () {
      if (state === 'playing') show(null);
      if (state === 'preview') show(lUnmute);
    });

    // ----- pantalla completa -----
    fsBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      if (document.fullscreenElement || document.webkitFullscreenElement) { exitFs(); return; }
      if (box.requestFullscreen) box.requestFullscreen();
      else if (box.webkitRequestFullscreen) box.webkitRequestFullscreen();
      else if (v.webkitEnterFullscreen) v.webkitEnterFullscreen();
    });
    function exitFs() {
      try {
        if (document.fullscreenElement && document.exitFullscreen) document.exitFullscreen();
        else if (document.webkitFullscreenElement && document.webkitExitFullscreen) document.webkitExitFullscreen();
        if (v.webkitDisplayingFullscreen && v.webkitExitFullscreen) v.webkitExitFullscreen();
      } catch (e) {}
    }

    // ----- directo (webinar evergreen) -----
    function serverNow() { return Date.now() - skew; }
    function liveOffset() { return liveStart ? (serverNow() - liveStart) / 1000 : 0; }
    var timer = null;
    function countdown(target, title) {
      state = 'waiting'; v.pause();
      clearInterval(timer);
      var p = panel('<small>' + esc(title) + '</small><div class="vslh-clock"></div>');
      var c = p.querySelector('.vslh-clock');
      function tick() {
        if (dead) return clearInterval(timer);
        var left = target - serverNow();
        c.textContent = clock(left);
        if (left <= 0) { clearInterval(timer); liveStart = target; begin(); }
      }
      tick(); timer = setInterval(tick, 1000);
    }
    function liveEnded() {
      state = 'ended'; v.pause(); bar.classList.remove('on');
      var nxt = cfg.live.next && cfg.live.next > serverNow() ? cfg.live.next : null;
      if (nxt) countdown(nxt, labels.ended || 'Esta sesión ha terminado. La próxima empieza en');
      else panel('<p>' + esc(labels.ended || 'Esta sesión ha terminado') + '</p>');
    }

    // ----- arranque -----
    function begin() {
      if (evergreen) {
        if (!liveStart) { if (cfg.live.next) countdown(cfg.live.next, labels.countdown || 'La sesión empieza en'); else panel('<p>No hay sesiones programadas</p>'); return; }
        if (dur && liveOffset() >= dur) { liveEnded(); return; }
      }
      if (ctx.startNow) { requestStart(); return; }
      if (autoplayOn) {
        v.muted = true; v.loop = !evergreen;
        if (evergreen) try { v.currentTime = liveOffset(); } catch (e) {}
        var p = v.play();
        state = 'preview'; show(lUnmute);
        if (p && p.then) p.then(function () { send('start'); }).catch(function () {});
      } else { state = 'idle'; show(lPlay); }
    }
    ready.then(begin);

    function startWithSound(from) {
      if (evergreen) from = liveOffset();
      state = 'playing'; v.loop = false; v.muted = false;
      try { v.currentTime = from || 0; } catch (e) {}
      maxT = from || 0;
      pctEl.textContent = ''; show(lLoad);
      if (!evergreen) bar.classList.add('on');
      var p = v.play();
      if (p && p.catch) p.catch(function () { state = 'paused'; show(lPlay); });
      ls('vslh_last', JSON.stringify({ sid: sid, vid: cfg.id, ts: Date.now() }));
      active = { sid: sid, onClick: clicked };
      send('play');
    }

    // Antes de empezar: formulario (si va al principio) y "continuar donde lo dejaste"
    function requestStart() {
      if (cfg.gate && !gateDone && !(Number(cfg.gate.at) > 0)) { showGate(function () { requestStart(); }); return; }
      askResumeOr(function () { startWithSound(0); });
    }
    function askResumeOr(cb) {
      if (evergreen || !cfg.resume) return cb();
      var saved = null;
      try { saved = JSON.parse(ls(resumeKey) || 'null'); } catch (e) {}
      var fresh = saved && saved.ts && (Date.now() - saved.ts) < (cfg.resumeDays || 30) * 86400000;
      if (fresh && saved.t > 15 && (!dur || saved.t < dur - 15)) {
        if (state === 'preview') v.pause();
        var p = panel('<p>Ya habías empezado a ver este vídeo</p><div class="row"><button data-a="c">Continuar viendo</button><button data-a="r">Empezar de nuevo</button></div>');
        var c = p.querySelector('[data-a="c"]'), r = p.querySelector('[data-a="r"]');
        c.style.cssText = 'background:' + color + ';color:#fff'; r.style.cssText = 'background:#fff;color:#111';
        c.onclick = function (e) { e.stopPropagation(); startWithSound(saved.t); };
        r.onclick = function (e) { e.stopPropagation(); ls(resumeKey, null); startWithSound(0); };
      } else cb();
    }

    // ----- formulario dentro del vídeo -----
    function showGate(after) {
      var g = cfg.gate;
      var prev = state; state = 'gate'; v.pause();
      var fields = (g.fields && g.fields.length) ? g.fields : [{ key: 'email', label: 'Tu email', type: 'email', required: true }];
      var html = '<p>' + esc(g.title || 'Introduce tus datos para seguir viendo') + '</p>' + (g.subtitle ? '<small>' + esc(g.subtitle) + '</small>' : '') + '<form novalidate>';
      fields.forEach(function (f) {
        var type = ['email', 'tel', 'text', 'number'].indexOf(f.type) > -1 ? f.type : 'text';
        html += '<input name="' + esc(f.key) + '" type="' + type + '" placeholder="' + esc(f.label) + (f.required ? ' *' : '') + '"' + (f.required ? ' data-req="1"' : '') + '>';
      });
      html += '<div class="err"></div><button type="submit">' + esc(g.button || 'Seguir viendo') + '</button>';
      if (g.skippable) html += '<button type="button" class="skip">' + esc(g.skipText || 'Saltar') + '</button>';
      html += '</form>';
      var p = panel(html);
      var form = p.querySelector('form');
      form.querySelector('button[type=submit]').style.cssText = 'background:' + color + ';color:#fff';
      form.addEventListener('click', function (e) { e.stopPropagation(); });
      form.onsubmit = function (e) {
        e.preventDefault();
        var data = {}, bad = '';
        form.querySelectorAll('input').forEach(function (i) {
          var val = i.value.trim(); data[i.name] = val;
          if (i.getAttribute('data-req') && !val) bad = 'Rellena los campos obligatorios';
          if (i.type === 'email' && val && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val)) bad = 'Revisa el email';
        });
        if (bad) { form.querySelector('.err').textContent = bad; return; }
        if (!preview) post('/api/lead', { sid: sid, vid: cfg.id, data: data, url: location.href.split('#')[0] });
        gateDone = true; ls(gateKey, '1');
        window.dispatchEvent(new CustomEvent('vsl:lead', { detail: { videoId: cfg.id, data: data } }));
        after();
      };
      var skip = form.querySelector('.skip');
      if (skip) skip.onclick = function () { gateDone = true; after(); };
      if (prev === 'preview') { /* sigue al pulsar */ }
    }

    // ----- preguntas interactivas -----
    function showQuestion(i) {
      var q = cfg.questions[i];
      answered[i] = true; state = 'question'; v.pause();
      var html = '<p>' + esc(q.text) + '</p><div class="vslh-opts">';
      (q.options || []).forEach(function (o, j) { html += '<button data-j="' + j + '">' + esc(o.label) + '</button>'; });
      html += '</div>';
      var p = panel(html);
      p.querySelectorAll('button').forEach(function (b) {
        b.style.cssText = 'background:#fff;color:#111';
        b.onclick = function (e) {
          e.stopPropagation();
          var o = q.options[+b.getAttribute('data-j')];
          send('answer', { answer: { q: q.text, a: o.label, t: Math.round(v.currentTime) } });
          window.dispatchEvent(new CustomEvent('vsl:answer', { detail: { videoId: cfg.id, question: q.text, answer: o.label } }));
          if (o.action === 'video' && o.video) { teardown(); init(root, o.video, { startNow: true }); return; }
          if (o.action === 'seek' && o.seconds != null) { try { v.currentTime = Number(o.seconds); } catch (er) {} }
          if (o.action === 'url' && o.url) { location.href = withSid(o.url, sid); return; }
          state = 'playing'; show(null); v.play();
        };
      });
    }

    function teardown() {
      dead = true; clearInterval(timer); flush();
      try { v.pause(); if (hls) hls.destroy(); } catch (e) {}
      root.removeAttribute('data-vslh-init');
    }

    lUnmute.addEventListener('click', requestStart);
    lPlay.addEventListener('click', function () {
      if (state === 'paused') { state = 'playing'; show(null); v.play(); return; }
      requestStart();
    });
    v.addEventListener('click', function () {
      if (state === 'playing' && allowPause) { v.pause(); state = 'paused'; show(lPlay); send('progress'); }
    });

    // ----- progreso -----
    var lastSave = 0;
    v.addEventListener('timeupdate', function () {
      if (state !== 'playing' || dead) return;
      var t = v.currentTime;
      if (t > maxT) maxT = t;
      if (dur) {
        var p = Math.min(1, t / dur);
        var shown = cfg.fastProgress && !evergreen ? 1 - Math.pow(1 - p, 2.2) : p;
        fill.style.width = (shown * 100).toFixed(2) + '%';
        var pct = (maxT / dur) * 100;
        THRESHOLDS.forEach(function (th) {
          if (pct >= th && !sentTh[th]) { sentTh[th] = 1; fbq('VSL_' + th, sid + '_' + th); pending = true; }
        });
      }
      // Formulario a mitad de vídeo
      if (cfg.gate && !gateDone && Number(cfg.gate.at) > 0 && t >= Number(cfg.gate.at)) {
        showGate(function () { state = 'playing'; show(null); v.play(); }); return;
      }
      // Preguntas
      for (var i = 0; i < (cfg.questions || []).length; i++) {
        var q = cfg.questions[i];
        if (!answered[i] && q && q.text && t >= Number(q.at) && t < Number(q.at) + 3) { showQuestion(i); return; }
      }
      // Pitch: elementos de la página + botón
      revealPage(cfg.id, t, cfg.revealAt, false);
      var pitchAt = cfg.revealAt != null ? cfg.revealAt : (cfg.cta ? cfg.cta.at : null);
      if (ctaBox && t >= cfg.cta.at && !ctaBox.classList.contains('on')) {
        ctaBox.classList.add('on');
        if (cfg.cta.exitFullscreen) exitFs();
      }
      if (!ctaFired && pitchAt != null && t >= pitchAt) { ctaFired = true; fbq('VSL_Pitch', sid + '_pitch'); send('cta'); }
      if (cfg.resume && !evergreen && Math.abs(t - lastSave) > 4) { lastSave = t; ls(resumeKey, JSON.stringify({ t: t, ts: Date.now() })); }
      if (pending || maxT - lastSent >= 10) { pending = false; lastSent = maxT; send('progress'); }
    });
    v.addEventListener('ended', function () {
      if (state !== 'playing') return;
      ls(resumeKey, null); maxT = dur || maxT; send('progress');
      if (evergreen) { liveEnded(); return; }
      state = 'paused'; show(lPlay);
    });

    function flush() { if (state === 'playing' || state === 'paused' || state === 'gate' || state === 'question') send('progress'); }
    document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'hidden') flush(); });
    window.addEventListener('pagehide', flush);
  }

  function scan() {
    document.querySelectorAll('[data-vsl]:not([data-vslh-init])').forEach(function (n) { init(n, n.getAttribute('data-vsl')); });
  }
  window.__vslh = { scan: scan };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', scan); else scan();
})();
