/*!
 * VSL Host — registro de conversiones
 * Pégalo en la página de gracias:
 *   <script async src="https://TU-APP/convert.js" data-value="97" data-funnel="Lanzamiento noviembre"></script>
 * Atribuye la venta a la sesión del vídeo: por el parámetro ?vsl_sid= que añade el player a los
 * enlaces, o por la última sesión vista en este navegador (mismo dominio, últimos 7 días).
 */
(function () {
  var s = document.currentScript;
  if (!s) return;
  var BASE = new URL(s.src).origin;
  var sid = new URLSearchParams(location.search).get('vsl_sid');
  if (!sid) {
    try {
      var last = JSON.parse(localStorage.getItem('vslh_last') || 'null');
      if (last && Date.now() - last.ts < 7 * 86400000) sid = last.sid;
    } catch (e) {}
  }
  if (!sid) return;
  var key = 'vslh_conv_' + sid;
  try { if (localStorage.getItem(key)) return; localStorage.setItem(key, '1'); } catch (e) {}
  var body = JSON.stringify({
    sid: sid,
    value: s.getAttribute('data-value'),
    funnel: s.getAttribute('data-funnel'),
    page: location.href.split('?')[0]
  });
  if (navigator.sendBeacon && navigator.sendBeacon(BASE + '/api/convert', body)) return;
  fetch(BASE + '/api/convert', { method: 'POST', body: body, keepalive: true, headers: { 'Content-Type': 'text/plain' } });
})();
