-- =====================================================================
-- VSL Host — esquema de base de datos (Supabase / Postgres)
-- Pegar entero en Supabase > SQL Editor > Run
-- =====================================================================

create extension if not exists pgcrypto;

-- ---------- Ajustes por usuario (Meta Pixel / CAPI) ----------
create table if not exists settings (
  owner_id uuid primary key references auth.users(id) on delete cascade,
  meta_pixel_id text,
  meta_capi_token text,
  meta_test_event_code text,
  updated_at timestamptz default now()
);

-- ---------- Vídeos ----------
create table if not exists videos (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  name text not null default 'Nuevo vídeo',
  stream_uid text not null,               -- id del vídeo en Cloudflare Stream
  status text not null default 'processing', -- processing | ready | error
  duration numeric,                       -- segundos
  aspect text not null default '16:9',    -- 16:9 | 9:16 | 1:1 | 4:5
  -- Player
  color text not null default '#E11D48',
  autoplay_muted boolean not null default true,
  unmute_title text not null default 'Tu vídeo ya ha comenzado',
  unmute_subtitle text not null default 'Haz clic para escuchar',
  fast_progress boolean not null default true,
  allow_pause boolean not null default true,
  resume_enabled boolean not null default true,
  thumbnail_time numeric not null default 1,
  -- CTA temporizado
  reveal_at numeric,                      -- segundo en que se muestran los elementos .vsl-reveal de la página
  cta_at numeric,                         -- segundo en que aparece el botón bajo el vídeo
  cta_text text,
  cta_url text,
  -- Eventos Meta
  meta_events boolean not null default true,
  created_at timestamptz default now()
);
create index if not exists videos_owner_idx on videos(owner_id);

-- ---------- Tests A/B ----------
create table if not exists ab_tests (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  video_a uuid not null references videos(id) on delete cascade,
  video_b uuid not null references videos(id) on delete cascade,
  split numeric not null default 0.5,     -- % de tráfico a la variante A
  active boolean not null default true,
  winner text,                            -- 'A' | 'B' cuando cierres el test
  created_at timestamptz default now()
);

-- ---------- Vistas (una fila por visitante y carga de página) ----------
create table if not exists views (
  id uuid primary key default gen_random_uuid(),
  session_id text not null unique,
  video_id uuid not null references videos(id) on delete cascade,
  test_id uuid references ab_tests(id) on delete set null,
  variant text,
  started boolean not null default false,  -- arrancó (autoplay o play)
  played boolean not null default false,   -- reproducción real: activó sonido / dio a play
  max_second numeric not null default 0,   -- hasta dónde llegó viendo con sonido
  duration numeric,
  reached_cta boolean not null default false,
  thresholds int[] not null default '{}',  -- 25/50/75/95 ya enviados a Meta
  utm_source text, utm_medium text, utm_campaign text, utm_content text, utm_term text,
  referrer text,
  page_url text,
  device text,
  country text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);
create index if not exists views_video_idx on views(video_id, created_at);
create index if not exists views_test_idx on views(test_id);

-- ---------- RLS ----------
alter table settings enable row level security;
alter table videos   enable row level security;
alter table ab_tests enable row level security;
alter table views    enable row level security;

drop policy if exists own_settings on settings;
create policy own_settings on settings for all using (owner_id = auth.uid()) with check (owner_id = auth.uid());
drop policy if exists own_videos on videos;
create policy own_videos on videos for all using (owner_id = auth.uid()) with check (owner_id = auth.uid());
drop policy if exists own_tests on ab_tests;
create policy own_tests on ab_tests for all using (owner_id = auth.uid()) with check (owner_id = auth.uid());
drop policy if exists own_views on views;
create policy own_views on views for select using (
  exists (select 1 from videos v where v.id = views.video_id and v.owner_id = auth.uid())
);
-- Las escrituras de views las hace el servidor con la service role (se salta RLS).

-- ---------- Curva de retención ----------
-- Devuelve, para cada punto del vídeo, el % de reproducciones que siguen viendo.
create or replace function video_retention(p_video uuid, p_from timestamptz, p_to timestamptz, p_points int default 120)
returns table(second numeric, viewers bigint, pct numeric)
language sql stable security invoker as $$
  with v as (select coalesce(duration, 0) d from videos where id = p_video),
  s as (
    select max_second from views
    where video_id = p_video and played and created_at between p_from and p_to
  ),
  tot as (select count(*)::numeric n from s),
  pts as (
    select generate_series(0, p_points)::numeric * (select d from v) / p_points as sec
  )
  select round(pts.sec, 1),
         (select count(*) from s where s.max_second >= pts.sec),
         case when (select n from tot) = 0 then 0
              else round(100.0 * (select count(*) from s where s.max_second >= pts.sec) / (select n from tot), 1) end
  from pts order by pts.sec;
$$;

-- =====================================================================
-- v2 — se puede ejecutar aunque ya tengas la v1 (todo es "if not exists")
-- =====================================================================

-- Ajustes de cuenta
alter table settings add column if not exists timezone text not null default 'Europe/Madrid';
alter table settings add column if not exists notify_email text;
alter table settings add column if not exists webhook_url text;
alter table settings add column if not exists getresponse_key text;
alter table settings add column if not exists getresponse_campaign text;
alter table settings add column if not exists export_token uuid not null default gen_random_uuid();

-- Player
alter table videos add column if not exists autoplay_mode text not null default 'always';   -- always | desktop | mobile | off
alter table videos add column if not exists bar_height int not null default 6;
alter table videos add column if not exists resume_days int not null default 30;
alter table videos add column if not exists show_fullscreen boolean not null default true;
alter table videos add column if not exists cta_style jsonb not null default '{}';
alter table videos add column if not exists cta_exit_fullscreen boolean not null default true;
-- Protección
alter table videos add column if not exists protected boolean not null default false;
alter table videos add column if not exists allowed_domains text;
-- Webinar evergreen
alter table videos add column if not exists mode text not null default 'vsl';               -- vsl | evergreen
alter table videos add column if not exists evergreen jsonb not null default '{}';
-- Formulario dentro del vídeo y preguntas interactivas
alter table videos add column if not exists gate jsonb not null default '{}';
alter table videos add column if not exists questions jsonb not null default '[]';
-- Avisos
alter table videos add column if not exists notify jsonb not null default '{}';
alter table videos add column if not exists webhook_url text;

-- Vistas: conversiones, respuestas, leads
alter table views add column if not exists click_second numeric;
alter table views add column if not exists converted boolean not null default false;
alter table views add column if not exists conversion_value numeric;
alter table views add column if not exists conversion_second numeric;
alter table views add column if not exists conversion_page text;
alter table views add column if not exists funnel text;
alter table views add column if not exists converted_at timestamptz;
alter table views add column if not exists answers jsonb not null default '[]';
alter table views add column if not exists lead boolean not null default false;

-- Leads del formulario dentro del vídeo
create table if not exists leads (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  video_id uuid references videos(id) on delete set null,
  session_id text,
  name text, email text, phone text,
  data jsonb not null default '{}',
  page_url text,
  created_at timestamptz default now()
);
create index if not exists leads_owner_idx on leads(owner_id, created_at);
alter table leads enable row level security;
drop policy if exists own_leads on leads;
create policy own_leads on leads for select using (owner_id = auth.uid());

-- Secretos internos (clave de firma de Cloudflare). Solo los lee el servidor.
create table if not exists app_secrets (key text primary key, value text not null);
alter table app_secrets enable row level security;
